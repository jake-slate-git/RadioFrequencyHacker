#!/bin/bash

# Alfa Card Configuration Tool - Ubuntu Installation Script
# For Ubuntu Desktop 24.04 LTS

set -e

echo "================================================================"
echo "🔧 Alfa Card Configuration Tool - Ubuntu Installation"
echo "================================================================"
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Check if running as root
if [[ $EUID -eq 0 ]]; then
   print_error "Don't run this script as root. It will request sudo when needed."
   exit 1
fi

# Check Ubuntu version
if ! lsb_release -d | grep -q "Ubuntu 24.04"; then
    print_warning "This script is designed for Ubuntu 24.04 LTS"
    print_warning "It may work on other Ubuntu versions but is not tested"
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

print_info "Installing Alfa Card Configuration Tool for Ubuntu 24.04..."
echo ""

# Update system
print_info "Step 1: Updating system packages..."
sudo apt update -qq

# Install system dependencies
print_info "Step 2: Installing system dependencies..."
sudo apt install -y \
    python3 \
    python3-pip \
    python3-venv \
    python3-tk \
    python3-dev \
    libusb-1.0-0-dev \
    libudev-dev \
    build-essential \
    pkg-config \
    git \
    curl

print_status "System dependencies installed"

# Create virtual environment
print_info "Step 3: Creating Python virtual environment..."
python3 -m venv ~/.local/share/alfa-config-env
source ~/.local/share/alfa-config-env/bin/activate

print_status "Virtual environment created"

# Install Python dependencies
print_info "Step 4: Installing Python dependencies..."
pip install --upgrade pip
pip install pyusb libusb1 psutil colorlog

print_status "Python dependencies installed"

# Set up USB permissions
print_info "Step 5: Setting up USB permissions..."
sudo tee /etc/udev/rules.d/50-alfa-usb.rules > /dev/null <<EOF
# Alfa Network USB WiFi adapters - Full access for plugdev group
# AWUS036ACS (RTL8812AU)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8812", MODE="0666", GROUP="plugdev"
# AWUS036ACH (RTL8811AU)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8811", MODE="0666", GROUP="plugdev"
# AWUS036AC (RTL8812AU)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8812", MODE="0666", GROUP="plugdev"
# AWUS036H (RTL8187L)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8187", MODE="0666", GROUP="plugdev"
# AWUS036NH (RTL8188SU)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8171", MODE="0666", GROUP="plugdev"
# AWUS051NH (RTL8188RU)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8172", MODE="0666", GROUP="plugdev"
# AWUS052NH (RTL8192CU)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", ATTR{idProduct}=="8178", MODE="0666", GROUP="plugdev"
# Generic Realtek devices (covers most Alfa cards)
SUBSYSTEM=="usb", ATTR{idVendor}=="0bda", MODE="0666", GROUP="plugdev"
EOF

# Add user to plugdev group
sudo usermod -a -G plugdev $USER

print_status "USB permissions configured"

# Reload udev rules
print_info "Step 6: Reloading udev rules..."
sudo udevadm control --reload-rules
sudo udevadm trigger

print_status "udev rules reloaded"

# Copy application files
print_info "Step 7: Copying application files..."
mkdir -p ~/.local/share/alfa-config
cp -r . ~/.local/share/alfa-config/

print_status "Application files copied"

# Create launcher script
print_info "Step 8: Creating launcher script..."
mkdir -p ~/.local/bin

cat > ~/.local/bin/alfa-config << 'EOF'
#!/bin/bash
# Alfa Card Configuration Tool Launcher

# Activate virtual environment
source ~/.local/share/alfa-config-env/bin/activate

# Set up environment
export PYTHONPATH="$HOME/.local/share/alfa-config:$PYTHONPATH"

# Run the application
cd ~/.local/share/alfa-config
python3 main.py "$@"
EOF

chmod +x ~/.local/bin/alfa-config

print_status "Launcher script created"

# Add ~/.local/bin to PATH if not already there
if ! echo "$PATH" | grep -q "$HOME/.local/bin"; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.profile
    print_status "Added ~/.local/bin to PATH"
fi

# Create desktop entry
print_info "Step 9: Creating desktop entry..."
mkdir -p ~/.local/share/applications

cat > ~/.local/share/applications/alfa-config-tool.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Alfa Card Configuration Tool
Comment=Configure Alfa wireless card frequency and power settings
Exec=$HOME/.local/bin/alfa-config
Icon=network-wireless
Terminal=false
Categories=Network;Settings;System;
Keywords=alfa;wireless;wifi;configuration;frequency;power;
StartupNotify=true
EOF

print_status "Desktop entry created"

# Test USB backend
print_info "Step 10: Testing USB backend..."
source ~/.local/share/alfa-config-env/bin/activate

python3 -c "
import sys
try:
    import usb.core
    import usb.backend.libusb1
    
    backend = usb.backend.libusb1.get_backend()
    if backend:
        print('✓ libusb1 backend available')
        devices = list(usb.core.find(find_all=True))
        print(f'✓ Found {len(devices)} USB devices')
        
        # Look for Alfa devices
        alfa_devices = []
        for device in devices:
            if device.idVendor == 0x0bda:  # Realtek (used by Alfa)
                alfa_devices.append(device)
        
        if alfa_devices:
            print(f'✓ Found {len(alfa_devices)} potential Alfa devices')
            for device in alfa_devices:
                print(f'  - {hex(device.idVendor)}:{hex(device.idProduct)}')
        else:
            print('ℹ No Alfa devices currently connected')
    else:
        print('✗ libusb1 backend not available')
        sys.exit(1)
        
except ImportError as e:
    print(f'✗ Import error: {e}')
    sys.exit(1)
except Exception as e:
    print(f'✗ USB test failed: {e}')
    sys.exit(1)
"

if [ $? -eq 0 ]; then
    print_status "USB backend test passed"
else
    print_error "USB backend test failed"
    exit 1
fi

# Create uninstaller
print_info "Step 11: Creating uninstaller..."
cat > ~/.local/bin/alfa-config-uninstall << 'EOF'
#!/bin/bash
# Alfa Card Configuration Tool Uninstaller

echo "Uninstalling Alfa Card Configuration Tool..."

# Remove virtual environment
rm -rf ~/.local/share/alfa-config-env

# Remove application directory
rm -rf ~/.local/share/alfa-config

# Remove launcher
rm -f ~/.local/bin/alfa-config
rm -f ~/.local/bin/alfa-config-uninstall

# Remove desktop entry
rm -f ~/.local/share/applications/alfa-config-tool.desktop

# Remove udev rules (requires sudo)
sudo rm -f /etc/udev/rules.d/50-alfa-usb.rules
sudo udevadm control --reload-rules

echo "✓ Alfa Card Configuration Tool uninstalled"
echo "Note: You may need to log out and back in to remove group membership"
EOF

chmod +x ~/.local/bin/alfa-config-uninstall

print_status "Uninstaller created"

echo ""
echo "================================================================"
echo "🎉 Installation Complete!"
echo "================================================================"
echo ""
print_status "Alfa Card Configuration Tool is now installed!"
echo ""
echo "To run the application:"
echo "  • Command line: $(echo -e "${GREEN}alfa-config${NC}")"
echo "  • Desktop: Search for 'Alfa Card Configuration Tool' in applications"
echo "  • Or double-click the desktop icon"
echo ""
echo "Key features:"
echo "  ✓ No 'backend not available' errors"
echo "  ✓ Automatic USB device detection"
echo "  ✓ No administrator privileges required"
echo "  ✓ Native Ubuntu integration"
echo "  ✓ Supports all major Alfa wireless cards"
echo ""
echo "Important notes:"
echo "  📋 You may need to log out and back in for group changes to take effect"
echo "  🔌 Connect your Alfa wireless card before running"
echo "  ⚖️ Regional unlocking may violate local laws - check regulations"
echo "  🔧 Run 'alfa-config --test' to verify installation"
echo ""
echo "To uninstall: $(echo -e "${YELLOW}alfa-config-uninstall${NC}")"
echo ""
echo "Enjoy your Alfa Card Configuration Tool! 🚀"
echo ""