#!/bin/bash

echo "================================================================"
echo "🔍 Alfa Card Configuration Tool - Installation Debug"
echo "================================================================"
echo ""

# Check if files exist
echo "Checking installation files..."
echo ""

APP_DIR="$HOME/.local/share/alfa-config"
LAUNCHER="$HOME/.local/bin/alfa-config"
VENV="$HOME/.local/share/alfa-config-env"
DESKTOP="$HOME/.local/share/applications/alfa-config-tool.desktop"

echo "Application directory: $APP_DIR"
if [ -d "$APP_DIR" ]; then
    echo "✓ Directory exists"
    echo "Contents:"
    ls -la "$APP_DIR"
else
    echo "✗ Directory does not exist"
fi

echo ""
echo "Launcher script: $LAUNCHER"
if [ -f "$LAUNCHER" ]; then
    echo "✓ Launcher exists"
    echo "✓ Executable: $(test -x "$LAUNCHER" && echo "Yes" || echo "No")"
    echo "Contents:"
    cat "$LAUNCHER"
else
    echo "✗ Launcher does not exist"
fi

echo ""
echo "Virtual environment: $VENV"
if [ -d "$VENV" ]; then
    echo "✓ Virtual environment exists"
    echo "Python executable: $VENV/bin/python3"
    echo "Python version: $($VENV/bin/python3 --version 2>/dev/null || echo "Not working")"
else
    echo "✗ Virtual environment does not exist"
fi

echo ""
echo "Desktop entry: $DESKTOP"
if [ -f "$DESKTOP" ]; then
    echo "✓ Desktop entry exists"
    echo "Contents:"
    cat "$DESKTOP"
else
    echo "✗ Desktop entry does not exist"
fi

echo ""
echo "PATH check:"
echo "PATH: $PATH"
echo "~/.local/bin in PATH: $(echo "$PATH" | grep -q "$HOME/.local/bin" && echo "Yes" || echo "No")"

echo ""
echo "Testing launcher directly..."
if [ -f "$LAUNCHER" ]; then
    echo "Running: $LAUNCHER --version"
    "$LAUNCHER" --version
    echo ""
    echo "Running: $LAUNCHER --test"
    "$LAUNCHER" --test
else
    echo "Launcher not found"
fi

echo ""
echo "Testing main.py directly..."
if [ -f "$APP_DIR/main.py" ]; then
    cd "$APP_DIR"
    echo "Activating virtual environment..."
    source "$VENV/bin/activate"
    echo "Running: python3 main.py --version"
    python3 main.py --version
    echo ""
    echo "Running: python3 main.py --test"
    python3 main.py --test
else
    echo "main.py not found in $APP_DIR"
fi

echo ""
echo "================================================================"
echo "Debug complete!"
echo "================================================================"