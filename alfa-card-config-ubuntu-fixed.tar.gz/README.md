# Alfa Card Configuration Tool

A powerful desktop application for configuring Alfa wireless network adapters on Ubuntu Desktop 24.04 LTS, providing advanced frequency and power management through an intuitive graphical interface.

![Alfa Config Tool](assets/alfa-config-icon.svg)

## Features

- 🔧 **Hardware Configuration**: Direct USB control of Alfa wireless cards
- 📡 **Frequency Management**: Configure 2.4GHz and 5GHz frequency bands
- ⚡ **Power Control**: Adjust transmission power levels
- 🌍 **Regional Unlocking**: Remove regional restrictions (use responsibly)
- 💾 **Profile Management**: Save and load device configurations
- 🔍 **Device Detection**: Automatic detection of connected Alfa cards
- 🛡️ **Safety Validation**: Built-in checks prevent dangerous configurations
- 📊 **Real-time Monitoring**: Live device status and configuration feedback

## Supported Devices

- **AWUS036ACS** (RTL8812AU) - Dual-band AC1200
- **AWUS036ACH** (RTL8811AU) - Dual-band AC600
- **AWUS036AC** (RTL8812AU) - Dual-band AC1200
- **AWUS036H** (RTL8187L) - 2.4GHz 802.11g/n
- **AWUS036NH** (RTL8188SU) - 2.4GHz 802.11n
- **AWUS051NH** (RTL8188RU) - 2.4GHz 802.11n
- **AWUS052NH** (RTL8192CU) - 2.4GHz 802.11n

## Quick Installation

### One-Command Installation
```bash
curl -fsSL https://raw.githubusercontent.com/yourusername/alfa-card-config/main/install.sh | bash
```

### Manual Installation
```bash
# Clone the repository
git clone https://github.com/yourusername/alfa-card-config.git
cd alfa-card-config

# Run the installer
chmod +x install.sh
./install.sh
```

## Usage

### Launch the Application
```bash
# Command line
alfa-config

# Or find "Alfa Card Configuration Tool" in your applications menu
```

### Basic Configuration
1. **Connect your Alfa wireless card**
2. **Launch the application**
3. **Select your device** from the Device Control tab
4. **Configure frequency and power** settings
5. **Apply changes** and save profiles

### Command Line Options
```bash
alfa-config --test           # Test installation
alfa-config --help           # Show help
alfa-config --version        # Show version
alfa-config --terminal       # Run in terminal mode
```

## Why Ubuntu?

Ubuntu Desktop 24.04 offers significant advantages over Windows for Alfa card configuration:

### ✅ Ubuntu Advantages
- **Native USB support** - No special drivers needed
- **libusb included** - Works out of the box
- **Automatic permissions** - udev rules handle device access
- **No admin required** - Runs as regular user
- **One-command setup** - Single script installation
- **Better hardware compatibility** - Standard Linux drivers

### ❌ Windows Issues
- "No backend available" errors
- Requires Zadig for driver installation
- Must run as administrator
- Complex multi-step setup
- Driver conflicts common

## Technical Details

### System Requirements
- **OS**: Ubuntu Desktop 24.04 LTS (recommended)
- **Python**: 3.8 or higher
- **RAM**: 512MB minimum
- **Storage**: 100MB for application
- **USB**: USB 2.0 or higher port

### Architecture
- **Backend**: Python with PyUSB for hardware communication
- **Frontend**: Tkinter for native Linux GUI
- **Configuration**: JSON-based settings storage
- **Permissions**: udev rules for device access
- **Packaging**: Standard Python setuptools

### Dependencies
- `pyusb` - USB device communication
- `libusb1` - Low-level USB access
- `tkinter` - GUI framework (included with Python)
- `psutil` - System monitoring
- `colorlog` - Enhanced logging

## Safety and Legal

### ⚠️ Important Warnings
- **Regional unlocking may violate local telecommunications laws**
- **Check your country's regulations before use**
- **Use at your own risk and responsibility**
- **Authors not liable for legal issues**

### 🛡️ Built-in Safety
- Frequency validation prevents illegal ranges
- Power limits prevent hardware damage
- Configuration backup before changes
- Real-time status monitoring

## Development

### Project Structure
```
alfa-card-config/
├── config/                 # Device profiles and settings
├── device/                 # USB communication and device management
├── gui/                    # Tkinter GUI components
├── utils/                  # Logging and validation utilities
├── assets/                 # Icons and resources
├── main.py                 # Application entry point
├── install.sh              # Ubuntu installation script
└── README.md              # This file
```

### Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test on Ubuntu 24.04
5. Submit a pull request

### Running Tests
```bash
# Run test suite
python3 test_app.py

# Test USB backend
alfa-config --test

# Debug mode
alfa-config --debug
```

## Troubleshooting

### Common Issues

**Application won't start**
```bash
# Check installation
alfa-config --test

# Reinstall
./install.sh
```

**No devices detected**
```bash
# Check USB permissions
groups | grep plugdev

# Reconnect device
sudo udevadm control --reload-rules
```

**Permission denied**
```bash
# Log out and back in for group changes
# Or restart your session
```

### Getting Help
- Check the logs: `~/.local/share/alfa-config/logs/`
- Run diagnostics: `alfa-config --test`
- Review device compatibility
- Ensure latest Ubuntu updates

## Uninstallation

```bash
# Remove the application
alfa-config-uninstall

# Or manual removal
rm -rf ~/.local/share/alfa-config-env
rm -rf ~/.local/share/alfa-config
rm -f ~/.local/bin/alfa-config
```

## License

MIT License - see LICENSE file for details

## Support

- **Issues**: Report bugs and feature requests on GitHub
- **Documentation**: See the wiki for detailed guides
- **Community**: Join discussions in the issues section

## Changelog

### Version 1.0.0
- Initial Ubuntu Desktop 24.04 release
- Full Alfa card support
- Native USB backend
- One-command installation
- GUI and command-line interfaces
- Comprehensive safety features

---

**Made with ❤️ for the Ubuntu and wireless security community**