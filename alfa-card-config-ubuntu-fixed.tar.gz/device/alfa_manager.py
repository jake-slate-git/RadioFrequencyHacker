"""
Alfa device manager - handles device communication and configuration
"""

import usb.core
import usb.util
import threading
import time
from typing import List, Dict, Optional

from device.usb_handler import USBHandler
from config.device_profiles import DeviceProfiles
from utils.logger import get_logger

class AlfaManager:
    """Manager for Alfa wireless devices"""
    
    # Common Alfa vendor IDs
    ALFA_VENDOR_IDS = [0x0bda, 0x148f, 0x2357, 0x0e8d]
    
    def __init__(self):
        self.logger = get_logger()
        self.usb_handler = USBHandler()
        self.device_profiles = DeviceProfiles()
        self.connected_devices = {}
        self.device_lock = threading.Lock()
        
    def get_available_devices(self) -> List[Dict]:
        """Get list of available Alfa devices"""
        devices = []
        
        try:
            # Find all USB devices
            usb_devices = usb.core.find(find_all=True)
            
            for device in usb_devices:
                if device.idVendor in self.ALFA_VENDOR_IDS:
                    device_info = self._get_device_info(device)
                    if device_info:
                        devices.append(device_info)
                        
        except Exception as e:
            self.logger.error(f"Error scanning for devices: {e}")
            
        return devices
    
    def _get_device_info(self, usb_device) -> Optional[Dict]:
        """Get device information from USB device"""
        try:
            # Get device profile
            profile = self.device_profiles.get_profile(usb_device.idVendor, usb_device.idProduct)
            
            device_info = {
                'id': f"{usb_device.idVendor:04x}:{usb_device.idProduct:04x}",
                'vendor_id': usb_device.idVendor,
                'product_id': usb_device.idProduct,
                'bus': usb_device.bus,
                'address': usb_device.address,
                'name': profile.get('name', 'Unknown Alfa Device'),
                'model': profile.get('model', 'Unknown'),
                'supported_bands': profile.get('supported_bands', []),
                'max_power': profile.get('max_power', 20),
                'usb_device': usb_device
            }
            
            return device_info
            
        except Exception as e:
            self.logger.error(f"Error getting device info: {e}")
            return None
    
    def connect_device(self, device_info: Dict) -> bool:
        """Connect to a device"""
        try:
            with self.device_lock:
                device_id = device_info['id']
                
                if device_id in self.connected_devices:
                    return True
                
                # Initialize USB connection
                usb_device = device_info['usb_device']
                
                # Set configuration
                usb_device.set_configuration()
                
                # Get the interface
                interface = usb_device.get_active_configuration()[(0, 0)]
                
                # Store connection
                self.connected_devices[device_id] = {
                    'device_info': device_info,
                    'usb_device': usb_device,
                    'interface': interface,
                    'connected_at': time.time()
                }
                
                self.logger.info(f"Connected to device: {device_info['name']}")
                return True
                
        except Exception as e:
            self.logger.error(f"Error connecting to device: {e}")
            return False
    
    def disconnect_device(self, device_info: Dict) -> bool:
        """Disconnect from a device"""
        try:
            with self.device_lock:
                device_id = device_info['id']
                
                if device_id in self.connected_devices:
                    # Clean up USB connection
                    usb_device = self.connected_devices[device_id]['usb_device']
                    usb.util.dispose_resources(usb_device)
                    
                    del self.connected_devices[device_id]
                    self.logger.info(f"Disconnected from device: {device_info['name']}")
                    
                return True
                
        except Exception as e:
            self.logger.error(f"Error disconnecting from device: {e}")
            return False
    
    def get_device_status(self, device_info: Dict) -> Dict:
        """Get current device status"""
        try:
            if not self.connect_device(device_info):
                raise Exception("Failed to connect to device")
            
            device_id = device_info['id']
            connection = self.connected_devices[device_id]
            
            # Read device status via USB commands
            # This is a simplified implementation - real implementation would
            # use device-specific commands
            status = {
                'connected': True,
                'model': device_info['model'],
                'frequency': self._read_frequency(connection),
                'power': self._read_power(connection),
                'temperature': self._read_temperature(connection),
                'region': self._read_region(connection)
            }
            
            return status
            
        except Exception as e:
            self.logger.error(f"Error getting device status: {e}")
            return {'connected': False, 'error': str(e)}
    
    def set_frequency(self, device_info: Dict, frequency: int) -> bool:
        """Set device frequency"""
        try:
            if not self.connect_device(device_info):
                raise Exception("Failed to connect to device")
            
            device_id = device_info['id']
            connection = self.connected_devices[device_id]
            
            # Validate frequency
            if not self._validate_frequency(device_info, frequency):
                raise Exception(f"Invalid frequency: {frequency}")
            
            # Send frequency command
            success = self._send_frequency_command(connection, frequency)
            
            if success:
                self.logger.info(f"Set frequency to {frequency} MHz")
                return True
            else:
                raise Exception("Failed to set frequency")
                
        except Exception as e:
            self.logger.error(f"Error setting frequency: {e}")
            return False
    
    def set_power(self, device_info: Dict, power: int) -> bool:
        """Set device power"""
        try:
            if not self.connect_device(device_info):
                raise Exception("Failed to connect to device")
            
            device_id = device_info['id']
            connection = self.connected_devices[device_id]
            
            # Validate power
            if not self._validate_power(device_info, power):
                raise Exception(f"Invalid power: {power}")
            
            # Send power command
            success = self._send_power_command(connection, power)
            
            if success:
                self.logger.info(f"Set power to {power} dBm")
                return True
            else:
                raise Exception("Failed to set power")
                
        except Exception as e:
            self.logger.error(f"Error setting power: {e}")
            return False
    
    def unlock_region(self, device_info: Dict) -> bool:
        """Unlock regional restrictions"""
        try:
            if not self.connect_device(device_info):
                raise Exception("Failed to connect to device")
            
            device_id = device_info['id']
            connection = self.connected_devices[device_id]
            
            # Send region unlock command
            success = self._send_region_unlock_command(connection)
            
            if success:
                self.logger.info("Region unlocked successfully")
                return True
            else:
                raise Exception("Failed to unlock region")
                
        except Exception as e:
            self.logger.error(f"Error unlocking region: {e}")
            return False
    
    def factory_reset(self, device_info: Dict) -> bool:
        """Factory reset device"""
        try:
            if not self.connect_device(device_info):
                raise Exception("Failed to connect to device")
            
            device_id = device_info['id']
            connection = self.connected_devices[device_id]
            
            # Send factory reset command
            success = self._send_factory_reset_command(connection)
            
            if success:
                self.logger.info("Factory reset completed")
                return True
            else:
                raise Exception("Failed to factory reset")
                
        except Exception as e:
            self.logger.error(f"Error factory resetting: {e}")
            return False
    
    def reset_device(self, device_info: Dict) -> bool:
        """Reset device (alias for factory_reset)"""
        return self.factory_reset(device_info)
    
    def _validate_frequency(self, device_info: Dict, frequency: int) -> bool:
        """Validate frequency for device"""
        supported_bands = device_info.get('supported_bands', [])
        
        for band in supported_bands:
            if band['min'] <= frequency <= band['max']:
                return True
        
        return False
    
    def _validate_power(self, device_info: Dict, power: int) -> bool:
        """Validate power for device"""
        max_power = device_info.get('max_power', 20)
        return 0 <= power <= max_power
    
    def _read_frequency(self, connection: Dict) -> int:
        """Read current frequency from device"""
        # Simplified implementation - would use actual device commands
        try:
            # Mock implementation
            return 2400  # Default frequency
        except Exception as e:
            self.logger.error(f"Error reading frequency: {e}")
            return 0
    
    def _read_power(self, connection: Dict) -> int:
        """Read current power from device"""
        # Simplified implementation - would use actual device commands
        try:
            # Mock implementation
            return 20  # Default power
        except Exception as e:
            self.logger.error(f"Error reading power: {e}")
            return 0
    
    def _read_temperature(self, connection: Dict) -> int:
        """Read device temperature"""
        # Simplified implementation
        try:
            # Mock implementation
            return 45  # Default temperature
        except Exception as e:
            self.logger.error(f"Error reading temperature: {e}")
            return 0
    
    def _read_region(self, connection: Dict) -> str:
        """Read device region"""
        # Simplified implementation
        try:
            # Mock implementation
            return "US"  # Default region
        except Exception as e:
            self.logger.error(f"Error reading region: {e}")
            return "Unknown"
    
    def _send_frequency_command(self, connection: Dict, frequency: int) -> bool:
        """Send frequency command to device"""
        try:
            # This would contain actual USB command implementation
            # For now, we'll simulate success
            usb_device = connection['usb_device']
            
            # Example command structure - would be device-specific
            command = [0x01, 0x02, frequency & 0xFF, (frequency >> 8) & 0xFF]
            
            # Send command (simplified)
            # usb_device.write(endpoint, command)
            
            return True
        except Exception as e:
            self.logger.error(f"Error sending frequency command: {e}")
            return False
    
    def _send_power_command(self, connection: Dict, power: int) -> bool:
        """Send power command to device"""
        try:
            # This would contain actual USB command implementation
            usb_device = connection['usb_device']
            
            # Example command structure
            command = [0x02, 0x01, power & 0xFF]
            
            # Send command (simplified)
            # usb_device.write(endpoint, command)
            
            return True
        except Exception as e:
            self.logger.error(f"Error sending power command: {e}")
            return False
    
    def _send_region_unlock_command(self, connection: Dict) -> bool:
        """Send region unlock command to device"""
        try:
            # This would contain actual USB command implementation
            usb_device = connection['usb_device']
            
            # Example unlock command
            command = [0xFF, 0xFF, 0x00, 0x01]  # Unlock sequence
            
            # Send command (simplified)
            # usb_device.write(endpoint, command)
            
            return True
        except Exception as e:
            self.logger.error(f"Error sending region unlock command: {e}")
            return False
    
    def _send_factory_reset_command(self, connection: Dict) -> bool:
        """Send factory reset command to device"""
        try:
            # This would contain actual USB command implementation
            usb_device = connection['usb_device']
            
            # Example reset command
            command = [0xFE, 0xFE, 0xFF, 0xFF]  # Reset sequence
            
            # Send command (simplified)
            # usb_device.write(endpoint, command)
            
            return True
        except Exception as e:
            self.logger.error(f"Error sending factory reset command: {e}")
            return False
    
    def cleanup(self):
        """Cleanup all connections"""
        with self.device_lock:
            for device_id, connection in self.connected_devices.items():
                try:
                    usb_device = connection['usb_device']
                    usb.util.dispose_resources(usb_device)
                except Exception as e:
                    self.logger.error(f"Error cleaning up device {device_id}: {e}")
            
            self.connected_devices.clear()
            self.logger.info("All device connections cleaned up")
