#!/usr/bin/env python3
"""
Test script to verify Alfa Card Configuration Tool installation
"""

import os
import sys
import subprocess
from pathlib import Path

def check_installation():
    """Check if the installation is working"""
    print("Testing Alfa Card Configuration Tool installation...")
    print("=" * 60)
    
    # Check if files exist
    app_dir = Path.home() / ".local/share/alfa-config"
    launcher = Path.home() / ".local/bin/alfa-config"
    venv = Path.home() / ".local/share/alfa-config-env"
    
    print(f"Application directory: {app_dir}")
    print(f"Exists: {app_dir.exists()}")
    
    if app_dir.exists():
        print("Files in application directory:")
        for item in app_dir.iterdir():
            print(f"  - {item.name}")
    
    print(f"\nLauncher script: {launcher}")
    print(f"Exists: {launcher.exists()}")
    print(f"Executable: {launcher.is_file() and os.access(launcher, os.X_OK)}")
    
    print(f"\nVirtual environment: {venv}")
    print(f"Exists: {venv.exists()}")
    
    # Check if main.py exists
    main_py = app_dir / "main.py"
    print(f"\nMain application: {main_py}")
    print(f"Exists: {main_py.exists()}")
    
    # Check PATH
    path_env = os.environ.get('PATH', '')
    local_bin = str(Path.home() / ".local/bin")
    print(f"\n~/.local/bin in PATH: {local_bin in path_env}")
    
    # Try to run the application
    if launcher.exists() and main_py.exists():
        print("\nTrying to run the application...")
        try:
            result = subprocess.run([str(launcher), "--help"], 
                                  capture_output=True, text=True, timeout=10)
            print(f"Exit code: {result.returncode}")
            print(f"Output: {result.stdout}")
            if result.stderr:
                print(f"Errors: {result.stderr}")
        except Exception as e:
            print(f"Error running application: {e}")
    
    # Check desktop entry
    desktop_entry = Path.home() / ".local/share/applications/alfa-config-tool.desktop"
    print(f"\nDesktop entry: {desktop_entry}")
    print(f"Exists: {desktop_entry.exists()}")
    
    print("\n" + "=" * 60)
    print("Installation test complete!")

if __name__ == "__main__":
    check_installation()