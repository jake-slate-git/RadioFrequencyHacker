# Ubuntu Quick Start Guide

## One-Command Installation

For Ubuntu Desktop 24.04 users, this is the fastest way to get started:

```bash
curl -fsSL https://raw.githubusercontent.com/yourusername/alfa-card-config/main/install.sh | bash
```

## What This Command Does

1. **Updates your system packages**
2. **Installs required dependencies** (Python, libusb, etc.)
3. **Sets up USB permissions** for Alfa devices
4. **Creates a virtual environment** for the application
5. **Installs the application** with all dependencies
6. **Creates desktop shortcuts** and launcher commands
7. **Tests the installation** to ensure everything works

## After Installation

### Launch the Application
```bash
alfa-config
```

### Or find it in your applications menu
Search for "Alfa Card Configuration Tool"

### Test Your Installation
```bash
alfa-config --test
```

## Why Ubuntu Desktop 24.04?

- ✅ **No "backend not available" errors** (unlike Windows)
- ✅ **Native USB support** built into the system
- ✅ **One-command installation** instead of complex setup
- ✅ **No administrator privileges** required for normal use
- ✅ **Better hardware compatibility** with Alfa devices
- ✅ **Automatic permissions** through udev rules

## Manual Installation (Alternative)

If you prefer to do it manually:

```bash
# Clone the repository
git clone https://github.com/yourusername/alfa-card-config.git
cd alfa-card-config

# Run the installer
chmod +x install.sh
./install.sh
```

## Supported Alfa Devices

- **AWUS036ACS** (RTL8812AU) - Works perfectly
- **AWUS036ACH** (RTL8811AU) - Native support
- **AWUS036AC** (RTL8812AU) - Full compatibility  
- **AWUS036H** (RTL8187L) - Excellent support
- **AWUS036NH** (RTL8188SU) - Stable drivers
- **AWUS051NH** (RTL8188RU) - Good compatibility
- **AWUS052NH** (RTL8192CU) - Standard support

## Basic Usage

1. **Connect your Alfa wireless card**
2. **Run the application**: `alfa-config`
3. **Select your device** from the list
4. **Configure frequency and power** settings
5. **Apply changes** and test

## Troubleshooting

### No devices detected
```bash
# Check if your card is recognized
lsusb | grep -i realtek

# Check USB permissions
groups | grep plugdev
```

### Permission issues
```bash
# Log out and back in to refresh group membership
# Or restart your session
```

### Installation issues
```bash
# Re-run the installer
./install.sh
```

## Comparison with Windows

| Feature | Ubuntu 24.04 | Windows 11 |
|---------|-------------|------------|
| Installation | One command | Multiple manual steps |
| USB Backend | Native libusb | Requires Zadig + drivers |
| Permissions | Automatic udev rules | Must run as administrator |
| Stability | Excellent | "No backend available" errors |
| Setup Time | 5 minutes | 30+ minutes |

## Legal Notice

⚠️ **Important**: Regional unlocking may violate local telecommunications laws. Check your country's regulations before use. Use at your own risk.

## Get Started Now

Ready to try it? Just run this command on Ubuntu Desktop 24.04:

```bash
curl -fsSL https://raw.githubusercontent.com/yourusername/alfa-card-config/main/install.sh | bash
```

Then launch with:
```bash
alfa-config
```

That's it! Your Alfa card configuration tool is ready to use.