"""
Device profiles and specifications for different Alfa models
"""

from typing import Dict, List, Optional
from utils.logger import get_logger

class DeviceProfiles:
    """Manages device profiles for different Alfa models"""
    
    def __init__(self):
        self.logger = get_logger()
        self.profiles = self._load_device_profiles()
    
    def _load_device_profiles(self) -> Dict:
        """Load device profiles for known Alfa models"""
        profiles = {
            # Alfa AWUS036ACS
            (0x0bda, 0x8812): {
                'name': 'Alfa AWUS036ACS',
                'model': 'AWUS036ACS',
                'chipset': 'RTL8812AU',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484},
                    {'name': '5GHz', 'min': 5150, 'max': 5825}
                ],
                'max_power': 30,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFF, 0xFF, 0x00, 0x01],
                    'power_unlock': [0xFF, 0xFF, 0x01, 0x01]
                }
            },
            
            # Alfa AWUS036ACH
            (0x0bda, 0x8811): {
                'name': 'Alfa AWUS036ACH',
                'model': 'AWUS036ACH',
                'chipset': 'RTL8811AU',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484},
                    {'name': '5GHz', 'min': 5150, 'max': 5825}
                ],
                'max_power': 33,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFF, 0xFF, 0x00, 0x01],
                    'power_unlock': [0xFF, 0xFF, 0x01, 0x01]
                }
            },
            
            # Alfa AWUS036AXM
            (0x0bda, 0x8832): {
                'name': 'Alfa AWUS036AXM',
                'model': 'AWUS036AXM',
                'chipset': 'RTL8832AU',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484},
                    {'name': '5GHz', 'min': 5150, 'max': 5825}
                ],
                'max_power': 35,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFF, 0xFF, 0x00, 0x01],
                    'power_unlock': [0xFF, 0xFF, 0x01, 0x01]
                }
            },
            
            # Alfa AWUS036NHA
            (0x148f, 0x7601): {
                'name': 'Alfa AWUS036NHA',
                'model': 'AWUS036NHA',
                'chipset': 'MT7601U',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484}
                ],
                'max_power': 30,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFE, 0xFE, 0x00, 0x01],
                    'power_unlock': [0xFE, 0xFE, 0x01, 0x01]
                }
            },
            
            # Alfa AWUS036NH
            (0x148f, 0x3070): {
                'name': 'Alfa AWUS036NH',
                'model': 'AWUS036NH',
                'chipset': 'RT3070',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484}
                ],
                'max_power': 30,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFD, 0xFD, 0x00, 0x01],
                    'power_unlock': [0xFD, 0xFD, 0x01, 0x01]
                }
            },
            
            # Alfa AWUS051NH
            (0x148f, 0x3572): {
                'name': 'Alfa AWUS051NH',
                'model': 'AWUS051NH',
                'chipset': 'RT3572',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484},
                    {'name': '5GHz', 'min': 5150, 'max': 5825}
                ],
                'max_power': 30,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFC, 0xFC, 0x00, 0x01],
                    'power_unlock': [0xFC, 0xFC, 0x01, 0x01]
                }
            },
            
            # Alfa AWUS1900
            (0x0bda, 0x8813): {
                'name': 'Alfa AWUS1900',
                'model': 'AWUS1900',
                'chipset': 'RTL8813AU',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484},
                    {'name': '5GHz', 'min': 5150, 'max': 5825}
                ],
                'max_power': 33,
                'supports_monitor': True,
                'supports_injection': True,
                'region_locked': True,
                'unlock_commands': {
                    'region_unlock': [0xFF, 0xFF, 0x00, 0x01],
                    'power_unlock': [0xFF, 0xFF, 0x01, 0x01]
                }
            },
            
            # Generic Alfa device (fallback)
            (0x0000, 0x0000): {
                'name': 'Generic Alfa Device',
                'model': 'Unknown',
                'chipset': 'Unknown',
                'supported_bands': [
                    {'name': '2.4GHz', 'min': 2400, 'max': 2484}
                ],
                'max_power': 20,
                'supports_monitor': False,
                'supports_injection': False,
                'region_locked': False,
                'unlock_commands': {}
            }
        }
        
        return profiles
    
    def get_profile(self, vendor_id: int, product_id: int) -> Dict:
        """Get device profile for vendor/product ID"""
        profile_key = (vendor_id, product_id)
        
        if profile_key in self.profiles:
            return self.profiles[profile_key].copy()
        
        # Try to find by vendor ID only
        for (vid, pid), profile in self.profiles.items():
            if vid == vendor_id and pid == 0x0000:
                return profile.copy()
        
        # Return generic profile
        generic_profile = self.profiles[(0x0000, 0x0000)].copy()
        generic_profile['name'] = f'Unknown Device ({vendor_id:04x}:{product_id:04x})'
        return generic_profile
    
    def get_all_profiles(self) -> Dict:
        """Get all device profiles"""
        return self.profiles.copy()
    
    def add_custom_profile(self, vendor_id: int, product_id: int, profile: Dict):
        """Add custom device profile"""
        try:
            profile_key = (vendor_id, product_id)
            self.profiles[profile_key] = profile
            self.logger.info(f"Added custom profile for {vendor_id:04x}:{product_id:04x}")
        except Exception as e:
            self.logger.error(f"Error adding custom profile: {e}")
            raise
    
    def remove_profile(self, vendor_id: int, product_id: int):
        """Remove device profile"""
        try:
            profile_key = (vendor_id, product_id)
            if profile_key in self.profiles:
                del self.profiles[profile_key]
                self.logger.info(f"Removed profile for {vendor_id:04x}:{product_id:04x}")
            else:
                raise KeyError(f"Profile not found for {vendor_id:04x}:{product_id:04x}")
        except Exception as e:
            self.logger.error(f"Error removing profile: {e}")
            raise
    
    def get_supported_frequencies(self, vendor_id: int, product_id: int) -> List[Dict]:
        """Get supported frequency bands for device"""
        profile = self.get_profile(vendor_id, product_id)
        return profile.get('supported_bands', [])
    
    def get_max_power(self, vendor_id: int, product_id: int) -> int:
        """Get maximum power for device"""
        profile = self.get_profile(vendor_id, product_id)
        return profile.get('max_power', 20)
    
    def supports_monitor_mode(self, vendor_id: int, product_id: int) -> bool:
        """Check if device supports monitor mode"""
        profile = self.get_profile(vendor_id, product_id)
        return profile.get('supports_monitor', False)
    
    def supports_injection(self, vendor_id: int, product_id: int) -> bool:
        """Check if device supports packet injection"""
        profile = self.get_profile(vendor_id, product_id)
        return profile.get('supports_injection', False)
    
    def is_region_locked(self, vendor_id: int, product_id: int) -> bool:
        """Check if device is region locked"""
        profile = self.get_profile(vendor_id, product_id)
        return profile.get('region_locked', False)
    
    def get_unlock_commands(self, vendor_id: int, product_id: int) -> Dict:
        """Get unlock commands for device"""
        profile = self.get_profile(vendor_id, product_id)
        return profile.get('unlock_commands', {})
    
    def validate_frequency(self, vendor_id: int, product_id: int, frequency: int) -> bool:
        """Validate frequency for device"""
        supported_bands = self.get_supported_frequencies(vendor_id, product_id)
        
        for band in supported_bands:
            if band['min'] <= frequency <= band['max']:
                return True
        
        return False
    
    def validate_power(self, vendor_id: int, product_id: int, power: int) -> bool:
        """Validate power level for device"""
        max_power = self.get_max_power(vendor_id, product_id)
        return 0 <= power <= max_power
    
    def get_frequency_ranges(self, vendor_id: int, product_id: int) -> List[str]:
        """Get frequency ranges as strings"""
        supported_bands = self.get_supported_frequencies(vendor_id, product_id)
        ranges = []
        
        for band in supported_bands:
            ranges.append(f"{band['name']}: {band['min']}-{band['max']} MHz")
        
        return ranges
