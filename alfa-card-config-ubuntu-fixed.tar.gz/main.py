#!/usr/bin/env python3
"""
Alfa Card Configuration Tool
Main application entry point
"""

import sys
import os
import tkinter as tk
from tkinter import messagebox
import threading
import logging

# Add the current directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gui.main_window import MainWindow
from utils.logger import setup_logging
from device.alfa_manager import AlfaManager

class AlfaConfigApp:
    """Main application class"""
    
    def __init__(self):
        self.root = None
        self.main_window = None
        self.alfa_manager = None
        self.logger = None
        
    def initialize(self):
        """Initialize the application"""
        try:
            # Setup logging
            self.logger = setup_logging()
            self.logger.info("Starting Alfa Card Configuration Tool")
            
            # Initialize device manager
            self.alfa_manager = AlfaManager()
            
            # Create main window
            self.root = tk.Tk()
            self.root.title("Alfa Card Configuration Tool")
            self.root.geometry("800x600")
            self.root.minsize(600, 400)
            
            # Set window icon (using SVG as text for fallback)
            try:
                # In a real implementation, you'd convert SVG to PhotoImage
                pass
            except Exception as e:
                self.logger.warning(f"Could not load icon: {e}")
            
            # Initialize main window
            self.main_window = MainWindow(self.root, self.alfa_manager)
            
            # Setup window closing protocol
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            
            return True
            
        except Exception as e:
            error_msg = f"Failed to initialize application: {str(e)}"
            if self.logger:
                self.logger.error(error_msg)
            messagebox.showerror("Initialization Error", error_msg)
            return False
    
    def run(self):
        """Run the application"""
        if not self.initialize():
            return 1
        
        try:
            self.logger.info("Application started successfully")
            self.root.mainloop()
            return 0
        except Exception as e:
            error_msg = f"Application error: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Application Error", error_msg)
            return 1
    
    def on_closing(self):
        """Handle application closing"""
        try:
            if self.main_window:
                self.main_window.cleanup()
            if self.alfa_manager:
                self.alfa_manager.cleanup()
            self.logger.info("Application closed")
        except Exception as e:
            self.logger.error(f"Error during cleanup: {e}")
        finally:
            self.root.destroy()

def main():
    """Main entry point"""
    # Handle command line arguments
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if arg in ['--help', '-h']:
            print("Alfa Card Configuration Tool")
            print("Usage: alfa-config [options]")
            print("Options:")
            print("  --help, -h     Show this help message")
            print("  --version, -v  Show version information")
            print("  --test         Test installation and USB backend")
            print("  --terminal     Run in terminal mode")
            return 0
        elif arg in ['--version', '-v']:
            print("Alfa Card Configuration Tool v1.0.0")
            print("Ubuntu Desktop 24.04 LTS")
            return 0
        elif arg == '--test':
            print("Testing installation...")
            try:
                # Test imports
                from device.alfa_manager import AlfaManager
                from gui.main_window import MainWindow
                print("✓ All modules imported successfully")
                
                # Test USB backend
                import usb.core
                backend = usb.core.get_backend()
                if backend:
                    print("✓ USB backend available")
                    devices = list(usb.core.find(find_all=True))
                    print(f"✓ Found {len(devices)} USB devices")
                else:
                    print("✗ USB backend not available")
                    return 1
                
                print("✓ Installation test passed")
                return 0
            except Exception as e:
                print(f"✗ Installation test failed: {e}")
                return 1
        elif arg == '--terminal':
            print("Terminal mode not yet implemented")
            return 0
    
    # Check for administrative privileges (Ubuntu doesn't need root with udev rules)
    if os.name == 'nt':  # Windows
        try:
            import ctypes
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
            if not is_admin:
                messagebox.showwarning(
                    "Administrative Rights Required",
                    "This application requires administrative privileges to access USB devices.\n"
                    "Please run as administrator."
                )
        except:
            pass
    # Note: Ubuntu uses udev rules instead of requiring root privileges
    
    # Create and run application
    app = AlfaConfigApp()
    return app.run()

if __name__ == "__main__":
    sys.exit(main())
