# Quick Fix Guide for Installation Issues

## Problem: Application Not Found After Installation

If you've run `install.sh` successfully but can't find the `alfa-config` command, here are the debugging steps:

### Step 1: Check Installation
Run the debug script to see what's missing:
```bash
chmod +x debug_install.sh
./debug_install.sh
```

### Step 2: Manual Path Fix
If the PATH isn't set correctly, add it manually:
```bash
export PATH="$HOME/.local/bin:$PATH"
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Step 3: Test the Installation
```bash
# Test if the command is available
which alfa-config

# If not available, run directly
~/.local/bin/alfa-config --version

# Test the application
~/.local/bin/alfa-config --test
```

### Step 4: Alternative Launch Methods

If the command still doesn't work, try these alternatives:

**Method 1: Direct execution**
```bash
cd ~/.local/share/alfa-config
source ~/.local/share/alfa-config-env/bin/activate
python3 main.py
```

**Method 2: Create manual launcher**
```bash
# Create a simple launcher script
cat > ~/alfa-config-launcher.sh << 'EOF'
#!/bin/bash
cd ~/.local/share/alfa-config
source ~/.local/share/alfa-config-env/bin/activate
python3 main.py "$@"
EOF

chmod +x ~/alfa-config-launcher.sh
./alfa-config-launcher.sh
```

**Method 3: Desktop launcher**
Look for "Alfa Card Configuration Tool" in your applications menu.

### Step 5: Reinstall if Necessary
If nothing works, reinstall:
```bash
# Remove old installation
rm -rf ~/.local/share/alfa-config
rm -rf ~/.local/share/alfa-config-env
rm -f ~/.local/bin/alfa-config

# Reinstall
./install.sh
```

## Common Issues and Solutions

### Issue: "Command not found"
**Solution:** PATH not set correctly
```bash
export PATH="$HOME/.local/bin:$PATH"
```

### Issue: "No module named 'usb'"
**Solution:** Virtual environment not activated
```bash
source ~/.local/share/alfa-config-env/bin/activate
```

### Issue: "Permission denied"
**Solution:** Make launcher executable
```bash
chmod +x ~/.local/bin/alfa-config
```

### Issue: "ModuleNotFoundError"
**Solution:** Missing dependencies
```bash
source ~/.local/share/alfa-config-env/bin/activate
pip install pyusb libusb1
```

## Test Your Installation

After fixing, run these tests:

```bash
# Test 1: Command availability
alfa-config --version

# Test 2: Installation test
alfa-config --test

# Test 3: Launch GUI
alfa-config
```

## Expected Output

When working correctly, you should see:
- `alfa-config --version` shows version information
- `alfa-config --test` shows "Installation test passed"
- `alfa-config` opens the GUI application
- Application appears in your system menu

## Get Help

If you're still having issues, run:
```bash
./debug_install.sh
```

And share the output for troubleshooting.