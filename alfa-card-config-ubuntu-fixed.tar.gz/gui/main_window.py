"""
Main window GUI implementation
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import threading
import json
import os

from gui.device_panel import DevicePanel
from gui.config_panel import ConfigPanel
from config.settings_manager import SettingsManager
from utils.logger import get_logger

class MainWindow:
    """Main application window"""
    
    def __init__(self, root, alfa_manager):
        self.root = root
        self.alfa_manager = alfa_manager
        self.logger = get_logger()
        self.settings_manager = SettingsManager()
        
        # GUI components
        self.notebook = None
        self.device_panel = None
        self.config_panel = None
        self.status_bar = None
        self.menu_bar = None
        
        # State variables
        self.current_device = None
        self.monitoring_thread = None
        self.monitoring_active = False
        
        self.setup_gui()
        self.setup_menu()
        self.setup_status_bar()
        self.start_monitoring()
        
    def setup_gui(self):
        """Setup the main GUI components"""
        # Create main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(0, weight=1)
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # Create device panel
        self.device_panel = DevicePanel(self.notebook, self.alfa_manager, self.on_device_selected)
        self.notebook.add(self.device_panel.frame, text="Device Control")
        
        # Create configuration panel
        self.config_panel = ConfigPanel(self.notebook, self.settings_manager)
        self.notebook.add(self.config_panel.frame, text="Configuration")
        
    def setup_menu(self):
        """Setup the menu bar"""
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)
        
        # File menu
        file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Load Configuration...", command=self.load_configuration)
        file_menu.add_command(label="Save Configuration...", command=self.save_configuration)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Device menu
        device_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Device", menu=device_menu)
        device_menu.add_command(label="Refresh Devices", command=self.refresh_devices)
        device_menu.add_command(label="Reset Device", command=self.reset_device)
        
        # Help menu
        help_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="About", command=self.show_about)
        
    def setup_status_bar(self):
        """Setup the status bar"""
        self.status_bar = ttk.Frame(self.root)
        self.status_bar.grid(row=1, column=0, sticky=(tk.W, tk.E), padx=10, pady=(0, 10))
        
        # Status label
        self.status_label = ttk.Label(self.status_bar, text="Ready")
        self.status_label.grid(row=0, column=0, sticky=tk.W)
        
        # Device count label
        self.device_count_label = ttk.Label(self.status_bar, text="Devices: 0")
        self.device_count_label.grid(row=0, column=1, sticky=tk.E)
        
        # Configure grid weights
        self.status_bar.columnconfigure(0, weight=1)
        
    def start_monitoring(self):
        """Start device monitoring thread"""
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self.monitor_devices, daemon=True)
        self.monitoring_thread.start()
        
    def monitor_devices(self):
        """Monitor devices in background thread"""
        while self.monitoring_active:
            try:
                # Refresh device list every 2 seconds
                self.root.after(0, self.refresh_devices)
                threading.Event().wait(2)
            except Exception as e:
                self.logger.error(f"Error in monitoring thread: {e}")
                
    def refresh_devices(self):
        """Refresh the device list"""
        try:
            devices = self.alfa_manager.get_available_devices()
            self.device_panel.update_device_list(devices)
            
            # Update status
            device_count = len(devices)
            self.device_count_label.config(text=f"Devices: {device_count}")
            
            if device_count > 0:
                self.update_status("Devices found")
            else:
                self.update_status("No devices found")
                
        except Exception as e:
            self.logger.error(f"Error refreshing devices: {e}")
            self.update_status("Error refreshing devices")
            
    def on_device_selected(self, device):
        """Handle device selection"""
        self.current_device = device
        self.update_status(f"Selected device: {device.get('name', 'Unknown')}")
        
    def update_status(self, message):
        """Update status bar message"""
        self.status_label.config(text=message)
        self.logger.info(f"Status: {message}")
        
    def load_configuration(self):
        """Load configuration from file"""
        try:
            filename = filedialog.askopenfilename(
                title="Load Configuration",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
            
            if filename:
                with open(filename, 'r') as f:
                    config = json.load(f)
                
                # Apply configuration
                self.config_panel.load_configuration(config)
                self.update_status(f"Configuration loaded from {os.path.basename(filename)}")
                
        except Exception as e:
            error_msg = f"Failed to load configuration: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Load Error", error_msg)
            
    def save_configuration(self):
        """Save configuration to file"""
        try:
            filename = filedialog.asksaveasfilename(
                title="Save Configuration",
                defaultextension=".json",
                filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
            )
            
            if filename:
                config = self.config_panel.get_configuration()
                
                with open(filename, 'w') as f:
                    json.dump(config, f, indent=2)
                
                self.update_status(f"Configuration saved to {os.path.basename(filename)}")
                
        except Exception as e:
            error_msg = f"Failed to save configuration: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Save Error", error_msg)
            
    def reset_device(self):
        """Reset the selected device"""
        if not self.current_device:
            messagebox.showwarning("No Device", "Please select a device first.")
            return
            
        try:
            result = messagebox.askyesno(
                "Reset Device",
                "Are you sure you want to reset the selected device?\n"
                "This will restore factory settings."
            )
            
            if result:
                self.alfa_manager.reset_device(self.current_device)
                self.update_status("Device reset successfully")
                messagebox.showinfo("Success", "Device has been reset to factory settings.")
                
        except Exception as e:
            error_msg = f"Failed to reset device: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Reset Error", error_msg)
            
    def show_about(self):
        """Show about dialog"""
        about_text = """Alfa Card Configuration Tool
        
A GUI application for configuring Alfa wireless card frequency and power settings.

Features:
- Device detection and connection
- Frequency and power adjustment
- Configuration save/load
- Real-time monitoring

Version: 1.0
"""
        messagebox.showinfo("About", about_text)
        
    def cleanup(self):
        """Cleanup resources"""
        self.monitoring_active = False
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=1)
        
        if self.device_panel:
            self.device_panel.cleanup()
        if self.config_panel:
            self.config_panel.cleanup()
