"""
Configuration panel GUI implementation
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os

from utils.logger import get_logger

class ConfigPanel:
    """Configuration management panel"""
    
    def __init__(self, parent, settings_manager):
        self.parent = parent
        self.settings_manager = settings_manager
        self.logger = get_logger()
        
        # GUI components
        self.frame = None
        
        # Configuration variables
        self.auto_connect_var = None
        self.auto_unlock_var = None
        self.default_frequency_var = None
        self.default_power_var = None
        self.log_level_var = None
        
        self.setup_gui()
        self.load_current_settings()
        
    def setup_gui(self):
        """Setup the configuration panel GUI"""
        self.frame = ttk.Frame(self.parent, padding="10")
        
        # General settings
        general_frame = ttk.LabelFrame(self.frame, text="General Settings", padding="10")
        general_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Auto-connect option
        self.auto_connect_var = tk.BooleanVar()
        ttk.Checkbutton(
            general_frame,
            text="Auto-connect to devices on startup",
            variable=self.auto_connect_var
        ).grid(row=0, column=0, sticky=tk.W)
        
        # Auto-unlock option
        self.auto_unlock_var = tk.BooleanVar()
        ttk.Checkbutton(
            general_frame,
            text="Auto-unlock regions (use with caution)",
            variable=self.auto_unlock_var
        ).grid(row=1, column=0, sticky=tk.W, pady=(5, 0))
        
        # Default settings
        defaults_frame = ttk.LabelFrame(self.frame, text="Default Settings", padding="10")
        defaults_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Default frequency
        ttk.Label(defaults_frame, text="Default Frequency (MHz):").grid(row=0, column=0, sticky=tk.W)
        self.default_frequency_var = tk.StringVar()
        ttk.Entry(defaults_frame, textvariable=self.default_frequency_var, width=10).grid(row=0, column=1, sticky=tk.W, padx=(10, 0))
        
        # Default power
        ttk.Label(defaults_frame, text="Default Power (dBm):").grid(row=1, column=0, sticky=tk.W, pady=(5, 0))
        self.default_power_var = tk.StringVar()
        ttk.Entry(defaults_frame, textvariable=self.default_power_var, width=10).grid(row=1, column=1, sticky=tk.W, padx=(10, 0), pady=(5, 0))
        
        # Application settings
        app_frame = ttk.LabelFrame(self.frame, text="Application Settings", padding="10")
        app_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Log level
        ttk.Label(app_frame, text="Log Level:").grid(row=0, column=0, sticky=tk.W)
        self.log_level_var = tk.StringVar()
        log_combo = ttk.Combobox(
            app_frame,
            textvariable=self.log_level_var,
            values=["DEBUG", "INFO", "WARNING", "ERROR"],
            state="readonly",
            width=10
        )
        log_combo.grid(row=0, column=1, sticky=tk.W, padx=(10, 0))
        
        # Profile management
        profile_frame = ttk.LabelFrame(self.frame, text="Profile Management", padding="10")
        profile_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Profile list
        ttk.Label(profile_frame, text="Saved Profiles:").grid(row=0, column=0, sticky=tk.W)
        
        self.profile_listbox = tk.Listbox(profile_frame, height=4)
        self.profile_listbox.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E), pady=5)
        
        # Profile buttons
        profile_button_frame = ttk.Frame(profile_frame)
        profile_button_frame.grid(row=2, column=0, columnspan=3, pady=(5, 0))
        
        ttk.Button(profile_button_frame, text="Load Profile", command=self.load_profile).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(profile_button_frame, text="Save Profile", command=self.save_profile).grid(row=0, column=1, padx=(5, 5))
        ttk.Button(profile_button_frame, text="Delete Profile", command=self.delete_profile).grid(row=0, column=2, padx=(5, 0))
        
        # Control buttons
        button_frame = ttk.Frame(self.frame)
        button_frame.grid(row=4, column=0, pady=(10, 0))
        
        ttk.Button(button_frame, text="Apply Settings", command=self.apply_settings).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(button_frame, text="Reset to Defaults", command=self.reset_to_defaults).grid(row=0, column=1, padx=(5, 5))
        ttk.Button(button_frame, text="Import Config", command=self.import_config).grid(row=0, column=2, padx=(5, 5))
        ttk.Button(button_frame, text="Export Config", command=self.export_config).grid(row=0, column=3, padx=(5, 0))
        
        # Configure grid weights
        self.frame.columnconfigure(0, weight=1)
        general_frame.columnconfigure(0, weight=1)
        defaults_frame.columnconfigure(1, weight=1)
        app_frame.columnconfigure(1, weight=1)
        profile_frame.columnconfigure(0, weight=1)
        
        # Load saved profiles
        self.refresh_profiles()
        
    def load_current_settings(self):
        """Load current settings from settings manager"""
        try:
            settings = self.settings_manager.get_all_settings()
            
            self.auto_connect_var.set(settings.get('auto_connect', False))
            self.auto_unlock_var.set(settings.get('auto_unlock', False))
            self.default_frequency_var.set(str(settings.get('default_frequency', 2400)))
            self.default_power_var.set(str(settings.get('default_power', 20)))
            self.log_level_var.set(settings.get('log_level', 'INFO'))
            
        except Exception as e:
            self.logger.error(f"Error loading settings: {e}")
            
    def apply_settings(self):
        """Apply current settings"""
        try:
            settings = {
                'auto_connect': self.auto_connect_var.get(),
                'auto_unlock': self.auto_unlock_var.get(),
                'default_frequency': int(self.default_frequency_var.get()),
                'default_power': int(self.default_power_var.get()),
                'log_level': self.log_level_var.get()
            }
            
            self.settings_manager.update_settings(settings)
            messagebox.showinfo("Success", "Settings applied successfully.")
            
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid numeric values for frequency and power.")
        except Exception as e:
            error_msg = f"Failed to apply settings: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Error", error_msg)
            
    def reset_to_defaults(self):
        """Reset settings to defaults"""
        result = messagebox.askyesno(
            "Reset Settings",
            "This will reset all settings to their default values.\n"
            "Are you sure?"
        )
        
        if result:
            try:
                self.settings_manager.reset_to_defaults()
                self.load_current_settings()
                messagebox.showinfo("Success", "Settings reset to defaults.")
            except Exception as e:
                error_msg = f"Failed to reset settings: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def refresh_profiles(self):
        """Refresh the profile list"""
        try:
            self.profile_listbox.delete(0, tk.END)
            profiles = self.settings_manager.get_profiles()
            
            for profile_name in profiles:
                self.profile_listbox.insert(tk.END, profile_name)
                
        except Exception as e:
            self.logger.error(f"Error refreshing profiles: {e}")
            
    def save_profile(self):
        """Save current settings as a profile"""
        profile_name = tk.simpledialog.askstring("Save Profile", "Enter profile name:")
        
        if profile_name:
            try:
                current_settings = {
                    'auto_connect': self.auto_connect_var.get(),
                    'auto_unlock': self.auto_unlock_var.get(),
                    'default_frequency': int(self.default_frequency_var.get()),
                    'default_power': int(self.default_power_var.get()),
                    'log_level': self.log_level_var.get()
                }
                
                self.settings_manager.save_profile(profile_name, current_settings)
                self.refresh_profiles()
                messagebox.showinfo("Success", f"Profile '{profile_name}' saved successfully.")
                
            except Exception as e:
                error_msg = f"Failed to save profile: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def load_profile(self):
        """Load selected profile"""
        selection = self.profile_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a profile to load.")
            return
            
        profile_name = self.profile_listbox.get(selection[0])
        
        try:
            profile_settings = self.settings_manager.load_profile(profile_name)
            
            self.auto_connect_var.set(profile_settings.get('auto_connect', False))
            self.auto_unlock_var.set(profile_settings.get('auto_unlock', False))
            self.default_frequency_var.set(str(profile_settings.get('default_frequency', 2400)))
            self.default_power_var.set(str(profile_settings.get('default_power', 20)))
            self.log_level_var.set(profile_settings.get('log_level', 'INFO'))
            
            messagebox.showinfo("Success", f"Profile '{profile_name}' loaded successfully.")
            
        except Exception as e:
            error_msg = f"Failed to load profile: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Error", error_msg)
            
    def delete_profile(self):
        """Delete selected profile"""
        selection = self.profile_listbox.curselection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a profile to delete.")
            return
            
        profile_name = self.profile_listbox.get(selection[0])
        
        result = messagebox.askyesno(
            "Delete Profile",
            f"Are you sure you want to delete the profile '{profile_name}'?"
        )
        
        if result:
            try:
                self.settings_manager.delete_profile(profile_name)
                self.refresh_profiles()
                messagebox.showinfo("Success", f"Profile '{profile_name}' deleted successfully.")
            except Exception as e:
                error_msg = f"Failed to delete profile: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def import_config(self):
        """Import configuration from file"""
        filename = filedialog.askopenfilename(
            title="Import Configuration",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                with open(filename, 'r') as f:
                    config = json.load(f)
                
                self.load_configuration(config)
                messagebox.showinfo("Success", "Configuration imported successfully.")
                
            except Exception as e:
                error_msg = f"Failed to import configuration: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def export_config(self):
        """Export current configuration to file"""
        filename = filedialog.asksaveasfilename(
            title="Export Configuration",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if filename:
            try:
                config = self.get_configuration()
                
                with open(filename, 'w') as f:
                    json.dump(config, f, indent=2)
                
                messagebox.showinfo("Success", "Configuration exported successfully.")
                
            except Exception as e:
                error_msg = f"Failed to export configuration: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def get_configuration(self):
        """Get current configuration as dictionary"""
        return {
            'auto_connect': self.auto_connect_var.get(),
            'auto_unlock': self.auto_unlock_var.get(),
            'default_frequency': int(self.default_frequency_var.get()),
            'default_power': int(self.default_power_var.get()),
            'log_level': self.log_level_var.get()
        }
        
    def load_configuration(self, config):
        """Load configuration from dictionary"""
        self.auto_connect_var.set(config.get('auto_connect', False))
        self.auto_unlock_var.set(config.get('auto_unlock', False))
        self.default_frequency_var.set(str(config.get('default_frequency', 2400)))
        self.default_power_var.set(str(config.get('default_power', 20)))
        self.log_level_var.set(config.get('log_level', 'INFO'))
        
    def cleanup(self):
        """Cleanup resources"""
        pass
