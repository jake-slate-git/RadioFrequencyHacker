"""
Device control panel GUI implementation
"""

import tkinter as tk
from tkinter import ttk, messagebox
import threading

from utils.logger import get_logger
from utils.validators import validate_frequency, validate_power

class DevicePanel:
    """Device control panel"""
    
    def __init__(self, parent, alfa_manager, device_callback):
        self.parent = parent
        self.alfa_manager = alfa_manager
        self.device_callback = device_callback
        self.logger = get_logger()
        
        # GUI components
        self.frame = None
        self.device_listbox = None
        self.frequency_var = None
        self.power_var = None
        self.status_var = None
        
        # State
        self.selected_device = None
        self.monitoring_active = False
        
        self.setup_gui()
        
    def setup_gui(self):
        """Setup the device panel GUI"""
        self.frame = ttk.Frame(self.parent, padding="10")
        
        # Device selection section
        device_frame = ttk.LabelFrame(self.frame, text="Device Selection", padding="10")
        device_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        
        # Device list
        ttk.Label(device_frame, text="Available Devices:").grid(row=0, column=0, sticky=tk.W)
        
        list_frame = ttk.Frame(device_frame)
        list_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        
        self.device_listbox = tk.Listbox(list_frame, height=5)
        self.device_listbox.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.device_listbox.bind('<<ListboxSelect>>', self.on_device_select)
        
        # Scrollbar for device list
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.device_listbox.yview)
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.device_listbox.config(yscrollcommand=scrollbar.set)
        
        # Configure grid weights
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        
        # Refresh button
        ttk.Button(device_frame, text="Refresh", command=self.refresh_devices).grid(row=2, column=0, sticky=tk.W, pady=5)
        
        # Device info section
        info_frame = ttk.LabelFrame(self.frame, text="Device Information", padding="10")
        info_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Status display
        self.status_var = tk.StringVar(value="No device selected")
        ttk.Label(info_frame, text="Status:").grid(row=0, column=0, sticky=tk.W)
        ttk.Label(info_frame, textvariable=self.status_var).grid(row=0, column=1, sticky=tk.W, padx=(10, 0))
        
        # Configuration section
        config_frame = ttk.LabelFrame(self.frame, text="Configuration", padding="10")
        config_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Frequency control
        ttk.Label(config_frame, text="Frequency (MHz):").grid(row=0, column=0, sticky=tk.W)
        self.frequency_var = tk.StringVar()
        frequency_spinbox = ttk.Spinbox(
            config_frame, 
            from_=2400, 
            to=6000, 
            increment=1,
            textvariable=self.frequency_var,
            width=10
        )
        frequency_spinbox.grid(row=0, column=1, sticky=tk.W, padx=5)
        
        # Power control
        ttk.Label(config_frame, text="Power (dBm):").grid(row=1, column=0, sticky=tk.W, pady=(5, 0))
        self.power_var = tk.StringVar()
        power_spinbox = ttk.Spinbox(
            config_frame,
            from_=0,
            to=30,
            increment=1,
            textvariable=self.power_var,
            width=10
        )
        power_spinbox.grid(row=1, column=1, sticky=tk.W, padx=5, pady=(5, 0))
        
        # Control buttons
        button_frame = ttk.Frame(config_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=(10, 0))
        
        ttk.Button(button_frame, text="Apply Settings", command=self.apply_settings).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(button_frame, text="Read Current", command=self.read_current_settings).grid(row=0, column=1, padx=(5, 0))
        
        # Advanced settings
        advanced_frame = ttk.LabelFrame(self.frame, text="Advanced", padding="10")
        advanced_frame.grid(row=3, column=0, columnspan=2, sticky=(tk.W, tk.E))
        
        # Region unlock
        ttk.Button(advanced_frame, text="Unlock Region", command=self.unlock_region).grid(row=0, column=0, padx=(0, 5))
        ttk.Button(advanced_frame, text="Factory Reset", command=self.factory_reset).grid(row=0, column=1, padx=(5, 0))
        
        # Configure main grid weights
        self.frame.columnconfigure(0, weight=1)
        device_frame.columnconfigure(0, weight=1)
        
    def update_device_list(self, devices):
        """Update the device list"""
        self.device_listbox.delete(0, tk.END)
        
        for device in devices:
            display_name = f"{device.get('name', 'Unknown')} - {device.get('id', 'N/A')}"
            self.device_listbox.insert(tk.END, display_name)
            
    def on_device_select(self, event):
        """Handle device selection"""
        selection = self.device_listbox.curselection()
        if selection:
            index = selection[0]
            try:
                devices = self.alfa_manager.get_available_devices()
                if index < len(devices):
                    self.selected_device = devices[index]
                    self.device_callback(self.selected_device)
                    self.update_device_info()
            except Exception as e:
                self.logger.error(f"Error selecting device: {e}")
                
    def update_device_info(self):
        """Update device information display"""
        if not self.selected_device:
            self.status_var.set("No device selected")
            return
            
        try:
            # Get device status
            status = self.alfa_manager.get_device_status(self.selected_device)
            self.status_var.set(f"Connected - {status.get('model', 'Unknown')}")
            
            # Update current settings
            current_freq = status.get('frequency', 0)
            current_power = status.get('power', 0)
            
            self.frequency_var.set(str(current_freq))
            self.power_var.set(str(current_power))
            
        except Exception as e:
            self.logger.error(f"Error updating device info: {e}")
            self.status_var.set("Error reading device")
            
    def refresh_devices(self):
        """Refresh device list"""
        try:
            devices = self.alfa_manager.get_available_devices()
            self.update_device_list(devices)
        except Exception as e:
            self.logger.error(f"Error refreshing devices: {e}")
            messagebox.showerror("Error", f"Failed to refresh devices: {str(e)}")
            
    def apply_settings(self):
        """Apply frequency and power settings"""
        if not self.selected_device:
            messagebox.showwarning("No Device", "Please select a device first.")
            return
            
        try:
            # Validate inputs
            frequency = int(self.frequency_var.get())
            power = int(self.power_var.get())
            
            if not validate_frequency(frequency):
                messagebox.showerror("Invalid Input", "Invalid frequency value.")
                return
                
            if not validate_power(power):
                messagebox.showerror("Invalid Input", "Invalid power value.")
                return
            
            # Apply settings
            self.alfa_manager.set_frequency(self.selected_device, frequency)
            self.alfa_manager.set_power(self.selected_device, power)
            
            messagebox.showinfo("Success", "Settings applied successfully.")
            self.update_device_info()
            
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid numeric values.")
        except Exception as e:
            error_msg = f"Failed to apply settings: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Error", error_msg)
            
    def read_current_settings(self):
        """Read current device settings"""
        if not self.selected_device:
            messagebox.showwarning("No Device", "Please select a device first.")
            return
            
        try:
            self.update_device_info()
            messagebox.showinfo("Success", "Current settings read successfully.")
        except Exception as e:
            error_msg = f"Failed to read settings: {str(e)}"
            self.logger.error(error_msg)
            messagebox.showerror("Error", error_msg)
            
    def unlock_region(self):
        """Unlock regional restrictions"""
        if not self.selected_device:
            messagebox.showwarning("No Device", "Please select a device first.")
            return
            
        result = messagebox.askyesno(
            "Unlock Region", 
            "This will unlock regional frequency restrictions.\n"
            "This may void your warranty and could be illegal in some regions.\n"
            "Continue?"
        )
        
        if result:
            try:
                self.alfa_manager.unlock_region(self.selected_device)
                messagebox.showinfo("Success", "Region unlocked successfully.")
                self.update_device_info()
            except Exception as e:
                error_msg = f"Failed to unlock region: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def factory_reset(self):
        """Factory reset the device"""
        if not self.selected_device:
            messagebox.showwarning("No Device", "Please select a device first.")
            return
            
        result = messagebox.askyesno(
            "Factory Reset",
            "This will reset the device to factory settings.\n"
            "All custom configurations will be lost.\n"
            "Continue?"
        )
        
        if result:
            try:
                self.alfa_manager.factory_reset(self.selected_device)
                messagebox.showinfo("Success", "Device reset to factory settings.")
                self.update_device_info()
            except Exception as e:
                error_msg = f"Failed to reset device: {str(e)}"
                self.logger.error(error_msg)
                messagebox.showerror("Error", error_msg)
                
    def cleanup(self):
        """Cleanup resources"""
        self.monitoring_active = False
