"""
USB communication handler for Alfa devices
"""

import usb.core
import usb.util
import usb.backend.libusb1
import threading
import time
import os
import sys
from typing import Optional, List, Dict

from utils.logger import get_logger

class USBHandler:
    """Handles low-level USB communication"""
    
    def __init__(self):
        self.logger = get_logger()
        self.timeout = 5000  # 5 second timeout
        self.backend = self._get_usb_backend()
        
    def _get_usb_backend(self):
        """Get the best available USB backend"""
        # Try different backends in order of preference
        backends = [
            ('libusb1', usb.backend.libusb1.get_backend),
            ('libusb0', lambda: usb.backend.get_backend('libusb0')),
            ('openusb', lambda: usb.backend.get_backend('openusb')),
            ('default', lambda: usb.backend.get_backend())
        ]
        
        for name, get_backend in backends:
            try:
                backend = get_backend()
                if backend is not None:
                    self.logger.info(f"Using USB backend: {name}")
                    return backend
            except Exception as e:
                self.logger.debug(f"Backend {name} not available: {e}")
                continue
        
        self.logger.warning("No USB backend available - device detection will fail")
        return None
        
    def find_devices(self, vendor_ids: List[int]) -> List:
        """Find USB devices by vendor IDs"""
        devices = []
        
        if self.backend is None:
            self.logger.error("No USB backend available")
            return devices
        
        try:
            for vendor_id in vendor_ids:
                found_devices = usb.core.find(find_all=True, idVendor=vendor_id, backend=self.backend)
                if found_devices:
                    devices.extend(found_devices)
                
        except Exception as e:
            self.logger.error(f"Error finding USB devices: {e}")
            
        return devices
    
    def get_device_descriptor(self, device) -> Optional[Dict]:
        """Get device descriptor information"""
        try:
            return {
                'idVendor': device.idVendor,
                'idProduct': device.idProduct,
                'bcdDevice': device.bcdDevice,
                'iManufacturer': device.iManufacturer,
                'iProduct': device.iProduct,
                'iSerialNumber': device.iSerialNumber,
                'bNumConfigurations': device.bNumConfigurations,
                'bus': device.bus,
                'address': device.address
            }
        except Exception as e:
            self.logger.error(f"Error getting device descriptor: {e}")
            return None
    
    def claim_interface(self, device, interface_number: int = 0) -> bool:
        """Claim USB interface"""
        try:
            if device.is_kernel_driver_active(interface_number):
                device.detach_kernel_driver(interface_number)
            
            usb.util.claim_interface(device, interface_number)
            return True
            
        except Exception as e:
            self.logger.error(f"Error claiming interface: {e}")
            return False
    
    def release_interface(self, device, interface_number: int = 0) -> bool:
        """Release USB interface"""
        try:
            usb.util.release_interface(device, interface_number)
            
            # Reattach kernel driver if needed
            if not device.is_kernel_driver_active(interface_number):
                device.attach_kernel_driver(interface_number)
                
            return True
            
        except Exception as e:
            self.logger.error(f"Error releasing interface: {e}")
            return False
    
    def control_transfer(self, device, bmRequestType: int, bRequest: int, 
                        wValue: int = 0, wIndex: int = 0, data_or_wLength=None) -> Optional[bytes]:
        """Perform USB control transfer"""
        try:
            if data_or_wLength is None:
                data_or_wLength = 0
            
            result = device.ctrl_transfer(
                bmRequestType, bRequest, wValue, wIndex, 
                data_or_wLength, timeout=self.timeout
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error in control transfer: {e}")
            return None
    
    def bulk_write(self, device, endpoint: int, data: bytes) -> int:
        """Write data to bulk endpoint"""
        try:
            return device.write(endpoint, data, timeout=self.timeout)
        except Exception as e:
            self.logger.error(f"Error in bulk write: {e}")
            return 0
    
    def bulk_read(self, device, endpoint: int, size: int) -> Optional[bytes]:
        """Read data from bulk endpoint"""
        try:
            return device.read(endpoint, size, timeout=self.timeout)
        except Exception as e:
            self.logger.error(f"Error in bulk read: {e}")
            return None
    
    def interrupt_write(self, device, endpoint: int, data: bytes) -> int:
        """Write data to interrupt endpoint"""
        try:
            return device.write(endpoint, data, timeout=self.timeout)
        except Exception as e:
            self.logger.error(f"Error in interrupt write: {e}")
            return 0
    
    def interrupt_read(self, device, endpoint: int, size: int) -> Optional[bytes]:
        """Read data from interrupt endpoint"""
        try:
            return device.read(endpoint, size, timeout=self.timeout)
        except Exception as e:
            self.logger.error(f"Error in interrupt read: {e}")
            return None
    
    def get_string_descriptor(self, device, index: int) -> Optional[str]:
        """Get string descriptor"""
        try:
            return usb.util.get_string(device, index)
        except Exception as e:
            self.logger.error(f"Error getting string descriptor: {e}")
            return None
    
    def reset_device(self, device) -> bool:
        """Reset USB device"""
        try:
            device.reset()
            return True
        except Exception as e:
            self.logger.error(f"Error resetting device: {e}")
            return False
    
    def set_configuration(self, device, configuration: int = 1) -> bool:
        """Set device configuration"""
        try:
            device.set_configuration(configuration)
            return True
        except Exception as e:
            self.logger.error(f"Error setting configuration: {e}")
            return False
    
    def get_active_configuration(self, device):
        """Get active configuration"""
        try:
            return device.get_active_configuration()
        except Exception as e:
            self.logger.error(f"Error getting active configuration: {e}")
            return None
    
    def is_device_connected(self, device) -> bool:
        """Check if device is still connected"""
        try:
            # Try to read device descriptor
            _ = device.idVendor
            return True
        except Exception:
            return False
    
    def find_endpoint(self, interface, direction: str, transfer_type: str) -> Optional[int]:
        """Find endpoint by direction and transfer type"""
        try:
            direction_map = {
                'out': usb.util.ENDPOINT_OUT,
                'in': usb.util.ENDPOINT_IN
            }
            
            type_map = {
                'bulk': usb.util.ENDPOINT_TYPE_BULK,
                'interrupt': usb.util.ENDPOINT_TYPE_INTR,
                'control': usb.util.ENDPOINT_TYPE_CTRL,
                'isochronous': usb.util.ENDPOINT_TYPE_ISO
            }
            
            endpoint = usb.util.find_descriptor(
                interface,
                custom_match=lambda e: \
                    usb.util.endpoint_direction(e.bEndpointAddress) == direction_map[direction] and \
                    usb.util.endpoint_type(e.bmAttributes) == type_map[transfer_type]
            )
            
            return endpoint.bEndpointAddress if endpoint else None
            
        except Exception as e:
            self.logger.error(f"Error finding endpoint: {e}")
            return None
    
    def dispose_resources(self, device):
        """Dispose of device resources"""
        try:
            usb.util.dispose_resources(device)
        except Exception as e:
            self.logger.error(f"Error disposing resources: {e}")
