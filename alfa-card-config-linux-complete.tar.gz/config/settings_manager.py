"""
Settings and configuration management
"""

import os
import json
import configparser
from typing import Dict, List, Any, Optional
from pathlib import Path

from utils.logger import get_logger

class SettingsManager:
    """Manages application settings and configuration"""
    
    def __init__(self):
        self.logger = get_logger()
        self.app_name = "AlfaConfigTool"
        self.config_dir = self._get_config_dir()
        self.settings_file = self.config_dir / "settings.json"
        self.profiles_dir = self.config_dir / "profiles"
        
        # Default settings
        self.default_settings = {
            'auto_connect': False,
            'auto_unlock': False,
            'default_frequency': 2400,
            'default_power': 20,
            'log_level': 'INFO',
            'window_width': 800,
            'window_height': 600,
            'window_x': 100,
            'window_y': 100,
            'check_updates': True,
            'backup_before_changes': True,
            'confirm_dangerous_operations': True
        }
        
        self._ensure_config_directories()
        self._load_settings()
    
    def _get_config_dir(self) -> Path:
        """Get the configuration directory path"""
        if os.name == 'nt':  # Windows
            config_dir = Path(os.getenv('APPDATA', '')) / self.app_name
        else:  # Linux/Mac
            config_dir = Path.home() / f'.{self.app_name.lower()}'
        
        return config_dir
    
    def _ensure_config_directories(self):
        """Ensure configuration directories exist"""
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
            self.profiles_dir.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            self.logger.error(f"Error creating config directories: {e}")
    
    def _load_settings(self):
        """Load settings from file"""
        try:
            if self.settings_file.exists():
                with open(self.settings_file, 'r') as f:
                    self.settings = json.load(f)
                
                # Merge with defaults for any missing keys
                for key, value in self.default_settings.items():
                    if key not in self.settings:
                        self.settings[key] = value
            else:
                self.settings = self.default_settings.copy()
                self._save_settings()
                
        except Exception as e:
            self.logger.error(f"Error loading settings: {e}")
            self.settings = self.default_settings.copy()
    
    def _save_settings(self):
        """Save settings to file"""
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(self.settings, f, indent=2)
        except Exception as e:
            self.logger.error(f"Error saving settings: {e}")
    
    def get_setting(self, key: str, default=None) -> Any:
        """Get a single setting"""
        return self.settings.get(key, default)
    
    def set_setting(self, key: str, value: Any):
        """Set a single setting"""
        self.settings[key] = value
        self._save_settings()
    
    def get_all_settings(self) -> Dict:
        """Get all settings"""
        return self.settings.copy()
    
    def update_settings(self, new_settings: Dict):
        """Update multiple settings"""
        self.settings.update(new_settings)
        self._save_settings()
    
    def reset_to_defaults(self):
        """Reset all settings to defaults"""
        self.settings = self.default_settings.copy()
        self._save_settings()
    
    def get_profiles(self) -> List[str]:
        """Get list of saved profiles"""
        try:
            profiles = []
            for profile_file in self.profiles_dir.glob("*.json"):
                profiles.append(profile_file.stem)
            return sorted(profiles)
        except Exception as e:
            self.logger.error(f"Error getting profiles: {e}")
            return []
    
    def save_profile(self, profile_name: str, profile_data: Dict):
        """Save a configuration profile"""
        try:
            profile_file = self.profiles_dir / f"{profile_name}.json"
            
            with open(profile_file, 'w') as f:
                json.dump(profile_data, f, indent=2)
                
            self.logger.info(f"Profile '{profile_name}' saved")
            
        except Exception as e:
            self.logger.error(f"Error saving profile '{profile_name}': {e}")
            raise
    
    def load_profile(self, profile_name: str) -> Dict:
        """Load a configuration profile"""
        try:
            profile_file = self.profiles_dir / f"{profile_name}.json"
            
            if not profile_file.exists():
                raise FileNotFoundError(f"Profile '{profile_name}' not found")
            
            with open(profile_file, 'r') as f:
                profile_data = json.load(f)
            
            self.logger.info(f"Profile '{profile_name}' loaded")
            return profile_data
            
        except Exception as e:
            self.logger.error(f"Error loading profile '{profile_name}': {e}")
            raise
    
    def delete_profile(self, profile_name: str):
        """Delete a configuration profile"""
        try:
            profile_file = self.profiles_dir / f"{profile_name}.json"
            
            if profile_file.exists():
                profile_file.unlink()
                self.logger.info(f"Profile '{profile_name}' deleted")
            else:
                raise FileNotFoundError(f"Profile '{profile_name}' not found")
                
        except Exception as e:
            self.logger.error(f"Error deleting profile '{profile_name}': {e}")
            raise
    
    def export_settings(self, file_path: str):
        """Export settings to file"""
        try:
            export_data = {
                'settings': self.settings,
                'profiles': {}
            }
            
            # Include all profiles
            for profile_name in self.get_profiles():
                export_data['profiles'][profile_name] = self.load_profile(profile_name)
            
            with open(file_path, 'w') as f:
                json.dump(export_data, f, indent=2)
                
            self.logger.info(f"Settings exported to '{file_path}'")
            
        except Exception as e:
            self.logger.error(f"Error exporting settings: {e}")
            raise
    
    def import_settings(self, file_path: str):
        """Import settings from file"""
        try:
            with open(file_path, 'r') as f:
                import_data = json.load(f)
            
            # Import settings
            if 'settings' in import_data:
                self.settings.update(import_data['settings'])
                self._save_settings()
            
            # Import profiles
            if 'profiles' in import_data:
                for profile_name, profile_data in import_data['profiles'].items():
                    self.save_profile(profile_name, profile_data)
            
            self.logger.info(f"Settings imported from '{file_path}'")
            
        except Exception as e:
            self.logger.error(f"Error importing settings: {e}")
            raise
    
    def backup_settings(self) -> str:
        """Create backup of current settings"""
        try:
            import datetime
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = self.config_dir / f"settings_backup_{timestamp}.json"
            
            self.export_settings(str(backup_file))
            return str(backup_file)
            
        except Exception as e:
            self.logger.error(f"Error creating settings backup: {e}")
            raise
    
    def restore_settings(self, backup_file: str):
        """Restore settings from backup"""
        try:
            self.import_settings(backup_file)
            self.logger.info(f"Settings restored from backup: {backup_file}")
        except Exception as e:
            self.logger.error(f"Error restoring settings: {e}")
            raise
    
    def get_recent_devices(self) -> List[Dict]:
        """Get recently used devices"""
        return self.get_setting('recent_devices', [])
    
    def add_recent_device(self, device_info: Dict):
        """Add device to recent devices list"""
        recent_devices = self.get_recent_devices()
        
        # Remove if already exists
        device_id = device_info.get('id')
        recent_devices = [d for d in recent_devices if d.get('id') != device_id]
        
        # Add to beginning
        recent_devices.insert(0, device_info)
        
        # Keep only last 10
        recent_devices = recent_devices[:10]
        
        self.set_setting('recent_devices', recent_devices)
