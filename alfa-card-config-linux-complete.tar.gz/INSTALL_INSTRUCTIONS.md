# Installation Instructions

## Ubuntu Desktop 24.04 One-Command Install

```bash
curl -fsSL https://raw.githubusercontent.com/yourusername/alfa-card-config/main/install.sh | bash
```

## Manual Installation

```bash
git clone https://github.com/yourusername/alfa-card-config.git
cd alfa-card-config
chmod +x install.sh
./install.sh
```

## After Installation

```bash
# Launch the application
alfa-config

# Test installation
alfa-config --test
```

## Files Structure

```
alfa-card-config/
├── config/                 # Device profiles and settings
│   ├── device_profiles.py  # Alfa device specifications
│   └── settings_manager.py # Configuration management
├── device/                 # USB communication
│   ├── alfa_manager.py     # Device manager
│   └── usb_handler.py      # USB communication
├── gui/                    # GUI components
│   ├── main_window.py      # Main application window
│   ├── device_panel.py     # Device control panel
│   └── config_panel.py     # Configuration panel
├── utils/                  # Utilities
│   ├── logger.py           # Logging system
│   └── validators.py       # Input validation
├── assets/                 # Icons and resources
│   └── alfa-config-icon.svg # Application icon
├── main.py                 # Application entry point
├── install.sh              # Ubuntu installation script
├── test_app.py             # Test suite
├── README.md               # Documentation
└── LICENSE                 # MIT license
```

## Requirements

- Ubuntu Desktop 24.04 LTS
- Python 3.8+
- USB 2.0+ port
- Alfa wireless card

## Usage

1. Connect your Alfa wireless card
2. Run `alfa-config`
3. Select your device from the Device Control tab
4. Configure frequency and power settings
5. Apply changes and save profiles

## Supported Devices

- AWUS036ACS (RTL8812AU)
- AWUS036ACH (RTL8811AU)
- AWUS036AC (RTL8812AU)
- AWUS036H (RTL8187L)
- AWUS036NH (RTL8188SU)
- AWUS051NH (RTL8188RU)
- AWUS052NH (RTL8192CU)