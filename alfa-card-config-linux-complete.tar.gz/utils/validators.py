"""
Validation utilities for device settings
"""

import re
from typing import List, Dict, Optional, Union

from utils.logger import get_logger

def validate_frequency(frequency: Union[int, str]) -> bool:
    """Validate frequency value"""
    try:
        freq = int(frequency)
        
        # Common WiFi frequency ranges
        valid_ranges = [
            (2400, 2500),  # 2.4GHz band
            (5150, 5875),  # 5GHz band
            (5925, 7125),  # 6GHz band (WiFi 6E)
        ]
        
        for min_freq, max_freq in valid_ranges:
            if min_freq <= freq <= max_freq:
                return True
        
        return False
        
    except (ValueError, TypeError):
        return False

def validate_power(power: Union[int, str]) -> bool:
    """Validate power level"""
    try:
        pwr = int(power)
        return 0 <= pwr <= 40  # dBm range
    except (ValueError, TypeError):
        return False

def validate_channel(channel: Union[int, str], band: str = "2.4GHz") -> bool:
    """Validate WiFi channel"""
    try:
        ch = int(channel)
        
        if band == "2.4GHz":
            return 1 <= ch <= 14
        elif band == "5GHz":
            # Common 5GHz channels
            valid_5ghz = [36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 
                         116, 120, 124, 128, 132, 136, 140, 144, 149, 153, 157, 161, 165]
            return ch in valid_5ghz
        elif band == "6GHz":
            # WiFi 6E channels
            return 1 <= ch <= 233
        
        return False
        
    except (ValueError, TypeError):
        return False

def validate_mac_address(mac: str) -> bool:
    """Validate MAC address format"""
    if not isinstance(mac, str):
        return False
    
    # Remove common separators
    mac = mac.replace(":", "").replace("-", "").replace(".", "")
    
    # Check if it's 12 hex characters
    if len(mac) != 12:
        return False
    
    try:
        int(mac, 16)
        return True
    except ValueError:
        return False

def validate_ssid(ssid: str) -> bool:
    """Validate SSID"""
    if not isinstance(ssid, str):
        return False
    
    # SSID length should be 1-32 characters
    if not (1 <= len(ssid) <= 32):
        return False
    
    # Check for valid characters (no null bytes)
    if '\x00' in ssid:
        return False
    
    return True

def validate_ip_address(ip: str) -> bool:
    """Validate IPv4 address"""
    if not isinstance(ip, str):
        return False
    
    parts = ip.split('.')
    if len(parts) != 4:
        return False
    
    try:
        for part in parts:
            num = int(part)
            if not (0 <= num <= 255):
                return False
        return True
    except ValueError:
        return False

def validate_port(port: Union[int, str]) -> bool:
    """Validate port number"""
    try:
        p = int(port)
        return 1 <= p <= 65535
    except (ValueError, TypeError):
        return False

def validate_hexadecimal(hex_string: str) -> bool:
    """Validate hexadecimal string"""
    if not isinstance(hex_string, str):
        return False
    
    # Remove common prefixes
    hex_string = hex_string.replace("0x", "").replace("0X", "")
    
    try:
        int(hex_string, 16)
        return True
    except ValueError:
        return False

def validate_device_id(device_id: str) -> bool:
    """Validate device ID format (vendor:product)"""
    if not isinstance(device_id, str):
        return False
    
    pattern = r'^[0-9a-fA-F]{4}:[0-9a-fA-F]{4}$'
    return bool(re.match(pattern, device_id))

def validate_frequency_range(min_freq: int, max_freq: int) -> bool:
    """Validate frequency range"""
    try:
        return (validate_frequency(min_freq) and 
                validate_frequency(max_freq) and 
                min_freq < max_freq)
    except:
        return False

def validate_power_range(min_power: int, max_power: int) -> bool:
    """Validate power range"""
    try:
        return (validate_power(min_power) and 
                validate_power(max_power) and 
                min_power < max_power)
    except:
        return False

def validate_configuration(config: Dict) -> List[str]:
    """Validate device configuration and return list of errors"""
    errors = []
    logger = get_logger()
    
    try:
        # Validate frequency
        if 'frequency' in config:
            if not validate_frequency(config['frequency']):
                errors.append(f"Invalid frequency: {config['frequency']}")
        
        # Validate power
        if 'power' in config:
            if not validate_power(config['power']):
                errors.append(f"Invalid power: {config['power']}")
        
        # Validate channel
        if 'channel' in config:
            band = config.get('band', '2.4GHz')
            if not validate_channel(config['channel'], band):
                errors.append(f"Invalid channel: {config['channel']} for band {band}")
        
        # Validate MAC address
        if 'mac_address' in config:
            if not validate_mac_address(config['mac_address']):
                errors.append(f"Invalid MAC address: {config['mac_address']}")
        
        # Validate SSID
        if 'ssid' in config:
            if not validate_ssid(config['ssid']):
                errors.append(f"Invalid SSID: {config['ssid']}")
        
        # Validate device ID
        if 'device_id' in config:
            if not validate_device_id(config['device_id']):
                errors.append(f"Invalid device ID: {config['device_id']}")
        
        # Validate ranges
        if 'frequency_range' in config:
            freq_range = config['frequency_range']
            if not validate_frequency_range(freq_range.get('min', 0), freq_range.get('max', 0)):
                errors.append("Invalid frequency range")
        
        if 'power_range' in config:
            power_range = config['power_range']
            if not validate_power_range(power_range.get('min', 0), power_range.get('max', 0)):
                errors.append("Invalid power range")
        
    except Exception as e:
        logger.error(f"Error validating configuration: {e}")
        errors.append(f"Validation error: {str(e)}")
    
    return errors

def sanitize_input(input_str: str) -> str:
    """Sanitize user input"""
    if not isinstance(input_str, str):
        return ""
    
    # Remove control characters
    sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', input_str)
    
    # Trim whitespace
    sanitized = sanitized.strip()
    
    return sanitized

def validate_file_path(file_path: str) -> bool:
    """Validate file path"""
    if not isinstance(file_path, str):
        return False
    
    # Check for path traversal attempts
    if '..' in file_path or file_path.startswith('/'):
        return False
    
    # Check for invalid characters
    invalid_chars = ['<', '>', ':', '"', '|', '?', '*']
    for char in invalid_chars:
        if char in file_path:
            return False
    
    return True

def validate_settings_dict(settings: Dict) -> List[str]:
    """Validate settings dictionary"""
    errors = []
    required_keys = ['default_frequency', 'default_power', 'log_level']
    
    for key in required_keys:
        if key not in settings:
            errors.append(f"Missing required setting: {key}")
    
    if 'default_frequency' in settings:
        if not validate_frequency(settings['default_frequency']):
            errors.append("Invalid default frequency")
    
    if 'default_power' in settings:
        if not validate_power(settings['default_power']):
            errors.append("Invalid default power")
    
    if 'log_level' in settings:
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if settings['log_level'] not in valid_levels:
            errors.append("Invalid log level")
    
    return errors
