#!/usr/bin/env python3
"""
Test script for Alfa Card Configuration Tool
Tests the application without requiring actual hardware
"""

import sys
import os
import unittest
from unittest.mock import Mock, patch
import tkinter as tk
from tkinter import ttk

# Add the current directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import application modules
from utils.validators import validate_frequency, validate_power
from utils.logger import setup_logging
from config.device_profiles import DeviceProfiles
from config.settings_manager import SettingsManager

class TestValidators(unittest.TestCase):
    """Test validation functions"""
    
    def test_frequency_validation(self):
        """Test frequency validation"""
        # Valid frequencies
        self.assertTrue(validate_frequency(2400))
        self.assertTrue(validate_frequency(2484))
        self.assertTrue(validate_frequency(5180))
        self.assertTrue(validate_frequency(5825))
        
        # Invalid frequencies
        self.assertFalse(validate_frequency(1000))
        self.assertFalse(validate_frequency(10000))
        self.assertFalse(validate_frequency(-100))
        self.assertFalse(validate_frequency("invalid"))
    
    def test_power_validation(self):
        """Test power validation"""
        # Valid power levels
        self.assertTrue(validate_power(0))
        self.assertTrue(validate_power(20))
        self.assertTrue(validate_power(30))
        
        # Invalid power levels
        self.assertFalse(validate_power(-5))
        self.assertFalse(validate_power(50))
        self.assertFalse(validate_power("invalid"))

class TestDeviceProfiles(unittest.TestCase):
    """Test device profile management"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.profiles = DeviceProfiles()
    
    def test_get_profile(self):
        """Test profile retrieval"""
        # Test known device
        profile = self.profiles.get_profile(0x0bda, 0x8812)
        self.assertIsNotNone(profile)
        self.assertEqual(profile['name'], 'Alfa AWUS036ACS')
        
        # Test unknown device
        profile = self.profiles.get_profile(0x9999, 0x9999)
        self.assertIsNotNone(profile)
        self.assertEqual(profile['name'], 'Unknown Device (9999:9999)')
    
    def test_frequency_validation(self):
        """Test device-specific frequency validation"""
        # Test valid frequency for AWUS036ACS
        self.assertTrue(self.profiles.validate_frequency(0x0bda, 0x8812, 2400))
        self.assertTrue(self.profiles.validate_frequency(0x0bda, 0x8812, 5180))
        
        # Test invalid frequency
        self.assertFalse(self.profiles.validate_frequency(0x0bda, 0x8812, 1000))

class TestSettingsManager(unittest.TestCase):
    """Test settings management"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.settings = SettingsManager()
    
    def test_default_settings(self):
        """Test default settings"""
        self.assertEqual(self.settings.get_setting('default_frequency'), 2400)
        self.assertEqual(self.settings.get_setting('default_power'), 20)
        self.assertEqual(self.settings.get_setting('log_level'), 'INFO')
    
    def test_setting_modification(self):
        """Test setting modification"""
        self.settings.set_setting('test_setting', 'test_value')
        self.assertEqual(self.settings.get_setting('test_setting'), 'test_value')

class TestGUIComponents(unittest.TestCase):
    """Test GUI components without displaying them"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.root = tk.Tk()
        self.root.withdraw()  # Hide the window
    
    def tearDown(self):
        """Clean up test fixtures"""
        self.root.destroy()
    
    def test_main_window_creation(self):
        """Test main window creation"""
        try:
            from gui.main_window import MainWindow
            from device.alfa_manager import AlfaManager
            
            # Mock the manager
            mock_manager = Mock(spec=AlfaManager)
            mock_manager.get_available_devices.return_value = []
            
            # Create main window
            main_window = MainWindow(self.root, mock_manager)
            
            # Check if components are created
            self.assertIsNotNone(main_window.notebook)
            self.assertIsNotNone(main_window.device_panel)
            self.assertIsNotNone(main_window.config_panel)
        except ImportError as e:
            # Skip test if pyusb not available
            self.skipTest(f"Skipping test due to missing dependency: {e}")
    
    def test_device_panel_creation(self):
        """Test device panel creation"""
        try:
            from gui.device_panel import DevicePanel
            from device.alfa_manager import AlfaManager
            
            # Mock the manager
            mock_manager = Mock(spec=AlfaManager)
            mock_manager.get_available_devices.return_value = []
            
            # Create device panel
            device_panel = DevicePanel(self.root, mock_manager, lambda x: None)
            
            # Check if components are created
            self.assertIsNotNone(device_panel.frame)
            self.assertIsNotNone(device_panel.device_listbox)
            self.assertIsNotNone(device_panel.frequency_var)
            self.assertIsNotNone(device_panel.power_var)
        except ImportError as e:
            # Skip test if pyusb not available
            self.skipTest(f"Skipping test due to missing dependency: {e}")

def run_gui_test():
    """Run a simple GUI test"""
    print("Testing GUI components...")
    
    try:
        # Create a test window
        root = tk.Tk()
        root.title("Alfa Config Tool - Test Mode")
        root.geometry("400x300")
        
        # Create test components
        label = ttk.Label(root, text="Alfa Card Configuration Tool")
        label.pack(pady=10)
        
        notebook = ttk.Notebook(root)
        notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Test tab 1
        tab1 = ttk.Frame(notebook)
        notebook.add(tab1, text="Device Control")
        
        ttk.Label(tab1, text="Device Control Panel").pack(pady=10)
        ttk.Button(tab1, text="Test Button").pack(pady=5)
        
        # Test tab 2
        tab2 = ttk.Frame(notebook)
        notebook.add(tab2, text="Configuration")
        
        ttk.Label(tab2, text="Configuration Panel").pack(pady=10)
        ttk.Checkbutton(tab2, text="Test Option").pack(pady=5)
        
        # Status bar
        status_frame = ttk.Frame(root)
        status_frame.pack(fill='x', padx=10, pady=5)
        ttk.Label(status_frame, text="Status: GUI Test Mode").pack(side='left')
        
        print("GUI test window created successfully!")
        print("Close the window to continue...")
        
        # Don't show the window in headless mode
        root.withdraw()
        root.after(1000, root.quit)  # Auto-close after 1 second
        root.mainloop()
        
        return True
        
    except Exception as e:
        print(f"GUI test failed: {e}")
        return False

def main():
    """Main test function"""
    print("=" * 50)
    print("Alfa Card Configuration Tool - Test Suite")
    print("=" * 50)
    
    # Test logging
    print("\n1. Testing logging system...")
    try:
        logger = setup_logging()
        logger.info("Logging test successful")
        print("✓ Logging system working")
    except Exception as e:
        print(f"✗ Logging test failed: {e}")
    
    # Test device profiles
    print("\n2. Testing device profiles...")
    try:
        profiles = DeviceProfiles()
        test_profile = profiles.get_profile(0x0bda, 0x8812)
        print(f"✓ Device profiles loaded: {test_profile['name']}")
    except Exception as e:
        print(f"✗ Device profiles test failed: {e}")
    
    # Test settings manager
    print("\n3. Testing settings manager...")
    try:
        settings = SettingsManager()
        freq = settings.get_setting('default_frequency')
        print(f"✓ Settings manager working: default frequency = {freq}")
    except Exception as e:
        print(f"✗ Settings manager test failed: {e}")
    
    # Test GUI components
    print("\n4. Testing GUI components...")
    try:
        success = run_gui_test()
        if success:
            print("✓ GUI components test passed")
        else:
            print("✗ GUI components test failed")
    except Exception as e:
        print(f"✗ GUI test failed: {e}")
    
    # Run unit tests
    print("\n5. Running unit tests...")
    try:
        # Create test suite using modern approach
        loader = unittest.TestLoader()
        suite = unittest.TestSuite()
        
        # Add test cases
        suite.addTest(loader.loadTestsFromTestCase(TestValidators))
        suite.addTest(loader.loadTestsFromTestCase(TestDeviceProfiles))
        suite.addTest(loader.loadTestsFromTestCase(TestSettingsManager))
        suite.addTest(loader.loadTestsFromTestCase(TestGUIComponents))
        
        # Run tests
        runner = unittest.TextTestRunner(verbosity=2)
        result = runner.run(suite)
        
        if result.wasSuccessful():
            print("✓ All unit tests passed")
        else:
            print("✗ Some unit tests failed")
            
    except Exception as e:
        print(f"✗ Unit tests failed: {e}")
    
    print("\n" + "=" * 50)
    print("Test complete!")
    print("=" * 50)

if __name__ == "__main__":
    main()