#!/usr/bin/env python3
"""
Setup script for Alfa Card Configuration Tool
Ubuntu Desktop 24.04 version
"""

from setuptools import setup, find_packages
import os

# Read README for long description
def read_readme():
    with open("README.md", "r", encoding="utf-8") as fh:
        return fh.read()

# Read requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="alfa-card-config",
    version="1.0.0",
    author="Alfa Card Configuration Tool",
    author_email="support@alfaconfig.com",
    description="Desktop application for configuring Alfa wireless card frequency and power settings",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/alfa-card-config",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: System :: Hardware",
        "Topic :: System :: Networking",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    entry_points={
        "console_scripts": [
            "alfa-config=main:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.md", "*.txt", "*.desktop", "*.png", "*.svg"],
    },
    data_files=[
        ("share/applications", ["alfa-config-tool.desktop"]),
        ("share/pixmaps", ["assets/alfa-config-icon.png"]),
        ("share/doc/alfa-config", ["README.md", "UBUNTU_ADVANTAGES.md"]),
    ],
)